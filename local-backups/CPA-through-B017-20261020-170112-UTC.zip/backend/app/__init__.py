"""CPA local foundation API."""
