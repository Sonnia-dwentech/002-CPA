"""Local, synthetic API tests."""
