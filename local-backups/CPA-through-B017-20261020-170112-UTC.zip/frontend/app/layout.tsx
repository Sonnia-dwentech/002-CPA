import type { Metadata } from "next";
import Shell from "../components/Shell";
import "./globals.css";
export const metadata: Metadata = {
  title: { default: "Command Centre · CPA", template: "%s · CPA" },
  description: "CPA local navigation preview. No live data or connected services.",
  robots: { index: false, follow: false },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en" data-scroll-behavior="smooth"><body><Shell>{children}</Shell></body></html>;
}
