import SessionJourney from "../../components/SessionJourney";
export const metadata = { title: "Sign-in unavailable" };
export default function SignIn() { return <SessionJourney />; }
