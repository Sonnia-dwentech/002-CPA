import Link from "next/link";
import Icon from "../components/Icon";
import { modules } from "../lib/modules";
export default function Home() {
  return <>
    <div className="page-heading"><div><p className="eyebrow">YOUR PRODUCT LABORATORY</p><h1>Command Centre</h1>
      <p className="page-description">A place to shape ideas, examine evidence and build better products.</p></div>
      <span className="phase-label">Foundation preview</span>
    </div>
    <section className="welcome-panel" aria-labelledby="welcome-title">
      <div className="welcome-copy"><span className="hero-label">FROM QUESTION TO POSSIBILITY</span>
        <h2 id="welcome-title">Good products begin<br className="desktop-break" /> with better questions.</h2>
        <p>Your workspace is taking shape. Explore the planned areas below and see what each will support.</p>
        <a className="hero-link" href="#planned-workspaces">Explore the workspace <Icon name="arrow" /></a>
      </div>
      <div className="hero-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" />
        <div className="orbit-center"><Icon name="idea" /></div><span className="orbit-dot dot-one" /><span className="orbit-dot dot-two" />
        <span className="orbit-word word-one">Explore</span><span className="orbit-word word-two">Question</span><span className="orbit-word word-three">Build</span>
      </div>
    </section>
    <div className="overview-grid">
      <section className="panel work-panel" aria-labelledby="work-title"><div className="section-heading">
        <h2 id="work-title">Your work, in one place</h2><span className="quiet-badge">Not connected</span></div>
        <div className="empty-content"><span className="empty-icon"><Icon name="grid" /></span>
          <h3>Records are not connected yet</h3><p>Ideas, reviews and activity will appear here when their workflows are available. No records or metrics are being queried in this preview.</p></div>
      </section>
      <section className="panel preview-panel" aria-labelledby="preview-title">
        <p className="eyebrow">ABOUT THIS PREVIEW</p><h2 id="preview-title">A clear starting point</h2>
        <ul className="preview-facts"><li><span className="fact-dot" />Navigation and page states are available to explore.</li>
          <li><span className="fact-line" />Sign-in and application data are not connected.</li>
          <li><span className="fact-line" />Research, scanning and voice services are unavailable.</li></ul>
        <a className="text-link" href="http://127.0.0.1:8000/">Open local backend status <Icon name="arrow" /></a>
        <small className="backend-note">Separate service · its page reports process liveness only.</small>
      </section>
    </div>
    <section id="planned-workspaces" className="planned" aria-labelledby="planned-title">
      <div className="section-heading"><div><p className="eyebrow">BUILT AROUND YOUR WORK</p><h2 id="planned-title">Planned workspaces</h2></div>
        <span className="section-note">Purpose first. Capabilities to follow.</span></div>
      <div className="module-grid">{["idea-studio", "stress-testing", "portfolio", "discovery-enquiries"].map(slug => {
        const item = modules.find(m => m.slug === slug)!;
        return <Link key={slug} href={`/${slug}`} className="module-card">
          <span className="module-icon"><Icon name={item.icon} /></span><span className="quiet-badge">Not available yet</span>
          <h3>{item.name}</h3><p>{item.description}</p><span className="module-link">View planned scope <Icon name="arrow" /></span>
        </Link>;
      })}</div>
    </section>
  </>;
}
