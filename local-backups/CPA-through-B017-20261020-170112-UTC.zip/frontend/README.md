# CPA local frontend

B015 implements the responsive navigation shell. Open **http://127.0.0.1:3000/** for the frontend; port 8000 is the separate backend status service. All eleven planned feature pages say “Not available yet”. No real sign-in, data API, research, voice or external service is connected in this normal application.

B016 adds a shared session-state component, an explicit unavailable page at `/sign-in`, and a [separately launched synthetic verification harness](harness/README.md). The harness uses ports 3100/8100 and disposable PostgreSQL; its issuance and server routes are absent from the normal app. See the [B016 report](../docs/evidence/B016-local-sign-in.md) for executed checks and acceptance limits.

From PowerShell:

```powershell
Set-Location 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\frontend'
npm run dev
```

Stop this server with Ctrl+C in its terminal. The launcher binds to 127.0.0.1:3000 only, disables Next telemetry and checks the installed Windows x64 native compiler before starting. It deliberately fails if that compiler is absent, rather than allowing Next to fetch a fallback.

Installed and verified locally: Node 24.21.0, npm 11.19.0, Next 16.3.8, React/React DOM 19.3.0, TypeScript 6.0.3, Node types 24.19.1 and React/React DOM types 19.3.0. This is a local compatibility result, not production qualification.

```powershell
npm run typecheck
npm run build
npm run start
```

Stop the development server before building because both use `.next`. `start` serves the completed production build on the same loopback port. On this host, sandboxed Next worker creation returned `spawn EPERM`; the same command succeeded with approved local execution permission.

## Offline dependencies

The user approved cache-only installation with lifecycle scripts disabled. `.npmrc` enforces offline mode, no install scripts, no audit/funding calls and project-local logs. Exact tarball URLs in `package.json` identify already-cached artifacts; they do not authorise downloads. `package-lock.json` records the resolved dependency tree.

To restore dependencies from a sufficiently populated local cache:

```powershell
npm ci --offline --ignore-scripts --no-audit --no-fund
```

Stop on a cache miss. Do not remove the offline flag or download missing packages. The initial install required permission to write npm's cache temporary files. Fresh-machine reproducibility remains a later B027 check.

## Design and evidence

See [B015 report](../docs/evidence/B015-local-navigation.md) for approved scope, token values, route/keyboard/responsive checks and remaining acceptance. Source labels come from D005; colours and spacing were derived locally from `UI.png` with user approval. System fonts and inline SVG/CSS decoration require no asset downloads.
