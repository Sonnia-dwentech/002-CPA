# ADR-003 — Local, staging and production separation

**Date:** 20 October 2026 UTC  
**Status:** Proposed for local review; no technical acceptance recorded  
**Prepared by:** Codex under the user's B005 controlled exception  
**Decision owner:** Justice; additional business authority identified below  
**Decision/date of approval:** Not recorded

## Context

[D003](../../CPA_Development_Handover_Pack_v1/docs/003-system-architecture-and-technology-specification.md), [D009](../../CPA_Development_Handover_Pack_v1/docs/009-deployment-operations-guide.md) and [F20](../../feature-spec.md#f20-operational-readiness-and-recovery) require separated environments, databases, secrets, API projects/quotas and recovery evidence. Render/GitHub Actions are proposed source choices, not verified deployed infrastructure.

## Options and trade-offs

| Option | Advantage to evaluate | Constraint / consequence |
| --- | --- | --- |
| Source-proposed hosting with separated environment services/configuration | Keeps the proposed operations guide as a starting point | Requires suitability, company ownership, cost and recovery review; no account, capability or service existence verified |
| Another hosting arrangement preserving the same boundaries | Allows evaluation if evidenced operational requirements rule out the proposal | Requires an explicit replacement ADR and revised setup/operations evidence; no alternate vendor selected |
| Shared staging/production data or credentials | Fewer items to configure | Conflicts with current environment separation requirements; not an acceptable shortcut under this baseline |

## Proposed logical boundary

| Environment | Intended purpose | Boundary for later implementation |
| --- | --- | --- |
| Local | Development and disposable verification | Approved synthetic fixtures; local configuration; mocked provider paths; no production/client data or shared production credentials |
| Staging | Approved integration and acceptance | Separate database, credentials and company API project/limits; live calls require separate authority; isolated storage/access |
| Production | Accepted release operations | Separate secrets/data/limits; named approved operators; release and recovery evidence |

This is a logical design proposal, not a claim that any environment exists. Placeholder configuration names in the source remain examples; real domains, origins, redirect URLs, secrets and service identifiers stay unset.

## Decisions required

Justice must record environment topology, configuration/secret ownership, allowed connectivity and data movement. Confirm storage boundaries and migration/rollback ownership. Justice and the relevant budget/operational authority must settle service sizing, spending ceilings, recovery/retention targets and support ownership at their specified checkpoints (O-07/O-16/O-17). Do not invent numeric targets or widen B005 into provisioning.

## B004-dependent portion — deferred

The source proposes feature/PR checks into develop, staging, then reviewed main releases. The design intent can be reviewed here. Actual branch existence/protection, required checks, bypass rights, repository secrets permissions and eligible reviewers cannot be declared operational. GitHub controls and PR #2 outcome remain B004 work. Hosting account rights and service readiness also require separate evidence; B004 alone would not prove them.

## Later verification

Map AC-F20-01 to authenticated staging UI/API/database and CI/config evidence; AC-F20-02 to actual restoration against agreed targets; AC-F20-03 to failing the launch gate for missing sign-off or critical security defects. B010/B023 and later staging/release tasks provide execution evidence. No services, credentials, paid accounts or deployments were created.
