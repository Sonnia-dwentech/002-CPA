# ADR-001 — Frontend, API and database boundary

**Date:** 20 October 2026 UTC  
**Status:** Proposed for local review; no technical acceptance recorded  
**Prepared by:** Codex under the user's B005 controlled exception  
**Decision owner:** Justice; additional business authority identified below  
**Decision/date of approval:** Not recorded

## Context and constraints

[D003](../../CPA_Development_Handover_Pack_v1/docs/003-system-architecture-and-technology-specification.md) proposes Next.js/TypeScript, FastAPI/Python and PostgreSQL with migrations. [Blueprint Section 9](../../blueprint.md#9-system-architecture) explicitly labels the stack provisional. The B005 task is architecture review, not scaffolding or installation. No remote implementation was inspected; compatibility with remote code is unknown.

## Options and trade-offs

| Option | Benefit to evaluate | Cost / unresolved consequence |
| --- | --- | --- |
| Retain the proposed separate Next.js UI, FastAPI API and PostgreSQL database | Preserves the source plan and gives the API a clear place to enforce permissions and own data contracts | Requires explicit UI/API contracts, session handling, two application runtimes and coordinated setup/deployment |
| Consolidate UI and backend responsibilities in one application runtime | Could reduce runtime/setup boundaries | Changes the supplied FastAPI plan; server-side permission, worker and provider boundaries still need design; requires an explicit scope/stack decision |
| Change the proposed database | May fit a later evidenced operational constraint | Requires a concrete reason and review of relational records, migrations, concurrency, isolation and recovery; no alternate database is selected here |

These are design trade-offs inferred from the local requirements, not benchmark results or current vendor capability comparisons.

## Review proposal — not an adopted decision

Retain the source stack as the primary candidate for Justice's evaluation. Place persistence and authoritative application checks behind the backend API; the browser must not access database or provider credentials. Keep UI rendering separate from permission enforcement. Define request/response validation and error contracts before implementation. Use versioned migrations for any chosen database.

This proposal does not select a hosting vendor, database service, framework version, package manager or migration library. Those need recorded decisions and later compatibility/setup verification. Frontend/backend consolidation remains an alternative if Justice records the rationale and changes to downstream task assumptions.

## Acceptance and consequences

Justice must record the selected stack/boundaries, options rejected, trade-offs and decision date. Record whether later FastAPI/PostgreSQL/Next.js task definitions remain valid; do not silently implement a different stack. Team capability, maintenance ownership and approved cost constraints are inputs still to confirm.

Future validation: approved local setup at B010; API contract/health at B011; migration apply/reapply and recovery implications at B012; UI/backend access boundaries at B013–B016. None has run. This ADR alone does not pass F01/F20 acceptance criteria.

## Dependencies and limits

- Current local requirements and O-03 are sufficient to review alternatives without B004.
- Repository contents, existing branch changes and actual integration compatibility remain B004-related unknowns; no claim of remote alignment is made.
- Deployment costs and operational constraints remain O-16/O-17; no provider commitment or provisioning.
- Related: [ADR-002](002-identity-roles-tenancy.md), [ADR-003](003-environments.md), [ADR-004](004-service-boundaries.md).
