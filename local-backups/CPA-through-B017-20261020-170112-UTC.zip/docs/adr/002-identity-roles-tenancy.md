# ADR-002 — Application identity, roles and tenancy

**Date:** 20 October 2026 UTC  
**Status:** Proposed for local review; no technical acceptance recorded  
**Prepared by:** Codex under the user's B005 controlled exception  
**Decision owner:** Justice; additional business authority identified below  
**Decision/date of approval:** Not recorded

## Context and authority

[F01](../../feature-spec.md#f01-authentication-and-record-access) requires authentication and server-side role/record checks, including search, exports, files and client isolation. O-04 is owned by Justice with the product owner for business grants. O-12 data handling is a separate prerequisite. GitHub membership does not establish an application's role or record privileges.

## Options and trade-offs

| Area / option | Benefit to evaluate | Cost / unresolved consequence |
| --- | --- | --- |
| Managed identity, using an approved provider | Delegates some identity lifecycle operations | Provider suitability, contracts, credentials, session integration, ownership and costs need review; application authorisation still belongs to CPA |
| Application-managed identity | Keeps identity lifecycle within the application design | Requires explicit responsibility for credentials, recovery, session security and operational support; no custom identity implementation is authorised |
| Shared database with server-enforced record/client scope, optionally database row policies | Common schema and migration path across scoped records | Every access path and worker context must enforce isolation; database-policy coverage and privileged bypasses need testing |
| Separate client schemas or databases | Separates client storage boundaries | Increases migration, connection, backup and operational coordination; business need and scale are unknown |

The blueprint lists Auth0, Clerk, Supabase Auth and custom identity as candidates. This ADR makes no claim about their current capabilities, pricing or suitability and selects none. A separate database per client is an analytical alternative, not a new requirement.

## Required design properties and open choices

Propose a deny-by-default application access policy, validated identity and backend enforcement for each action/resource. Permission checks must cover background job outputs and download paths as well as API reads/writes. Never infer client scope solely from a submitted identifier or infer authorisation from hidden UI controls. Exact ownership keys, sharing rules, token/session design, expiry/revocation and database policy remain open.

| Actor from the spec | Source intent to preserve | Product/technical decision still required |
| --- | --- | --- |
| Founder/CEO | Commercial/investment and release authority | Application read/write scope; do not infer unrestricted data access |
| Human CPA | Ideas, research, challenge and dossier work | Owned/shared/team visibility, actions and approval separation |
| Justice | Technical design and acceptance | Explicit application administration and infrastructure grants |
| Human assistant developer | Assigned implementation; no production secrets/unilateral release by default | Named account and environment access; repository permissions are B004 |
| Future analyst | Contributions under a future permission model | Whether enabled in initial scope and exact grants |
| Discovery client | Own permitted intake and approved responses | External identity, ownership proof, consent and later client workflow |
| AI | Drafts and recommendations | No human approval/investment/contract/release authority |

This table is a review worksheet, not an implemented or approved role matrix. Client-facing authentication is not pulled into the initial release merely by reviewing future isolation requirements.

## Decision and later verification

Justice and the product owner must record identity approach, required role/action/resource grants, sharing model and tenancy boundary before affected implementation. No real client data is permitted on the strength of this ADR; B006/O-12 policy remains outstanding.

Future checks map to AC-F01-01 (unauthenticated/invalid session denial), AC-F01-02 (unauthorised record/API/search/file denial) and AC-F01-03 (cross-client identifier substitution denied). Include job execution and exports in negative cases, and verify session expiry/revocation against the approved policy. These are planned checks; none has passed.

## B004 boundary

The application design can be reviewed locally. Actual developer GitHub accounts, MFA, repository privileges and eligible non-author PR reviewers remain unverified under B004. This ADR cannot grant those privileges or claim an eligible repository review occurred. Business grants, session policy and tenancy choices remain open independently of B004.
