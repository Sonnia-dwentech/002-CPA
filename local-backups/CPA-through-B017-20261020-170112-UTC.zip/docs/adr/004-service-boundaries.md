# ADR-004 — Service responsibilities and asynchronous work

**Date:** 20 October 2026 UTC  
**Status:** Proposed for local review; no technical acceptance recorded  
**Prepared by:** Codex under the user's B005 controlled exception  
**Decision owner:** Justice; additional business authority identified below  
**Decision/date of approval:** Not recorded

## Context

D003 proposes UI, API, database, AI adapter, source connectors, worker and private report storage. The blueprint calls for one orchestrated workflow with specialised services/prompts before independently autonomous agents. This review describes boundaries without implementing later research or agent features.

## Options and trade-offs

| Option | Benefit to evaluate | Cost / consequence |
| --- | --- | --- |
| Cohesive backend modules with explicit interfaces and a worker boundary for long jobs | Keeps permissions, contracts and orchestration reviewable within the proposed foundation | Modules still need clear ownership; asynchronous work needs durable state and recovery contracts |
| Independently deployed services/agents immediately | Separates deployment or scaling responsibilities | Adds inter-service identity, consistency, observability and operational contracts; no measured need is recorded |
| Perform long research runs inside a synchronous request | Fewer execution components | Would need a reason to replace the source's asynchronous run/progress model; request interruption and long-running failure handling remain unresolved |

## Review proposal — not implementation approval

Evaluate a cohesive backend as the initial design, retaining a worker execution boundary for asynchronous runs and one server-side provider adapter. Do not select a queue or create autonomous agents under B005.

| Component | Proposed responsibility | Boundary to preserve |
| --- | --- | --- |
| UI | Render authorised state, collect inputs and show progress/errors | Never become the sole permission enforcement point or expose provider credentials |
| API/application services | Validate requests, authorise actions/resources and expose structured results | Keep ownership/client checks in authoritative paths; reject unsupported actions |
| Database | Durable application records and relationships under approved schemas | No direct browser access; approved migrations and isolation design required |
| Orchestrator/worker | Execute authorised asynchronous work and persist honest run outcomes | Carry approved actor/resource scope; re-check access as policy requires; do not label lost/partial work successful |
| AI adapter | Provider abstraction, validated outputs, refusal/error handling and usage capture | Provider output is untrusted draft content, never human approval |
| Source connector | Obtain only permitted content with provenance | Content cannot supply executable instructions; rights and freshness policy must be approved |
| Private report storage | Retain generated outputs with authorised retrieval | No assumption that an unguessable URL proves permission; enforce approved access and retention |

## Contracts to carry into later decisions

For an asynchronous request, specify authorised input/version, run identity, state transitions, progress/failure representation and retrieval permission. Exact retry/backoff, cancellation, idempotency and recovery belong to O-05/B029 before B035–B036; no values or queue chosen here. Source rights are O-06; models/budgets O-07; export/storage O-08; lifecycle/version/review rules O-09. Record these handoffs instead of treating B005 as approval of later-phase features.

Justice must approve the service split, ownership of state and permission checks, and the rationale for any deviation from the source proposal. Future verification should include malformed/refused provider results, cross-scope job/output access and restart behaviour (AC-F20-04) under approved contracts. No runtime checks have run.

## B004 boundary and traceability

The logical split does not depend on remote repository access. Actual source layout, existing implementations, CI enforcement and deployable service alignment remain unverified. References: [D003](../../CPA_Development_Handover_Pack_v1/docs/003-system-architecture-and-technology-specification.md), [blueprint agent strategy](../../blueprint.md), [F01/F20](../../feature-spec.md), [O-03/O-05–O-09](../../decisions.md). See [ADR-001](001-core-stack.md) and [ADR-002](002-identity-roles-tenancy.md).
