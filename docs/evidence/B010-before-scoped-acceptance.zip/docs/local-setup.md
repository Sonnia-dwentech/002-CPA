# Windows Local Setup — B010 Preparation

**Version:** 0.1 draft · **Date:** 20 October 2026 UTC  
**State:** Setup preparation only; fresh application setup is not verified

## Current evidence and decisions

Observed local executables: Python 3.14.8, Node v24.21.0, npm 11.19.0 and Docker CLI 29.8.2. The Python launcher lists Python 3.14 only. No psql executable was found on PATH; that does not prove PostgreSQL is absent everywhere or that a database service is running. Docker server/image availability was not checked. These observations are local inventory, not approved application compatibility.

User approved Python 3.14.8, Node 24.21.0 and npm 11.19.0 as provisional local tooling, with compatibility unverified and no installs/downloads. User explicitly chose “Defer database setup; document blocker”. Docker is observed only, not an approved database setup choice. The proposed FastAPI/Next.js/PostgreSQL architecture still has B005 review requirements. No pinned application dependency set, lockfile, backend/frontend manifest or runnable application exists. Do not infer compatible versions from installed tools alone.

## Safe read-only preflight

Open PowerShell and run:

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA'
powershell.exe -NoProfile -File .\scripts\check-local-setup.ps1
```

**Observed attempt:** The documented `powershell.exe -NoProfile -File` invocation was rejected because script execution is disabled on this machine. No execution-policy change was made. The PowerShell parser accepted the script syntax; end-to-end script execution remains unverified. Manual version probes succeeded. Resolve an authorised execution method before relying on this command.

The script invokes only local executable version commands and validates the public `.env.example`. It does not inspect a private `.env`, connect to a database, query Docker's daemon, download packages, initialise Git or start services. It is anchored to its own project path and can also be called by absolute path from another directory.

Exit **2** is expected while application setup is incomplete; it is not a success/readiness signal. Exit **1** means template validation failed. The check intentionally cannot claim setup-ready from executable presence. If local execution policy prevents the script, report that result; do not change the machine policy as part of this guide.

## Configuration template

[.env.example](../.env.example) contains only empty configuration values and local defaults. No password, provider key, live address or cost ceiling is invented. `LIVE_AI_ENABLED=false` is a proposed future application switch, not an implemented security control. Empty cost/model/credential values must cause future affected operations to fail closed; they do not mean unlimited or free usage.

Do not put real values into the example. `DATABASE_URL`, `FRONTEND_ORIGIN`, identity settings and storage destination await approved local configuration. No example is interpreted by application code yet. No private `.env` is created by B010 preparation.

After approved configuration and only when a private local file is actually needed, this guarded copy avoids overwriting existing values:

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA'
if (Test-Path -LiteralPath '.env') {
    throw 'Existing .env preserved; review locally without exposing its contents.'
}
Copy-Item -LiteralPath '.env.example' -Destination '.env' -ErrorAction Stop
```

That copy alone does not configure or launch an application. Never paste private values into reports/chat. Future source-control setup must exclude private environment files before adding files; no Git operation is authorised here.

## Required next decisions and verification

1. Provisional installed-runtime baseline is approved as recorded above; pin/verify actual application dependencies before treating it as a supported setup. Any provisional installed-tool baseline needs later checks against the actual approved application dependencies.
2. Database setup is explicitly deferred by the user. Before full setup verification, obtain a later selected local PostgreSQL approach and disposable test destination. Native and Docker setup remain alternatives; do not pull/start an image or install a service without separate authority. No credentials or database names are inferred.
3. Approve application dependency/tool versions and obtain them through an explicitly authorised channel. Existing local dependencies may be used only after suitability is checked; no internet access is implied by task selection.
4. Define a repeatable isolated setup, locked dependency installation and startup/check commands once meaningful application manifests exist under authorised tasks. Do not invent run commands or scaffold later-task code merely to claim B010 passed.
5. Verify a fresh disposable setup with actual approved runtimes, capture commands/results and validate configuration isolation. B010's original completion check remains unmet until that evidence exists or the user explicitly revises its scope/dependency plan.

The source sequence places startup/database implementation at B011/B012. No later task has started. If full setup verification requires their artifacts, record a specific scoped dependency adjustment for approval; do not silently reorder tasks or mark B010 Done.

## Boundaries

G0-L permits selected local work with task-specific decisions. No GitHub connection, external provider, package download, live client data, cloud resource or deployment is authorised by this guide. Use synthetic fixtures only under [B006 policy](policies/allowed-data-and-test-fixtures.md). Source reference: [D009 configuration list](../CPA_Development_Handover_Pack_v1/docs/009-deployment-operations-guide.md).
