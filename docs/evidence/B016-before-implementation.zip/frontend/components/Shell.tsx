"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { modules } from "../lib/modules";
import Icon from "./Icon";

export default function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null);
  const previous = useRef(pathname);
  useEffect(() => {
    if (previous.current !== pathname) {
      previous.current = pathname;
      setOpen(false);
      document.getElementById("main-content")?.focus();
    }
  }, [pathname]);
  const current = modules.find(m => `/${m.slug}` === pathname);
  return <div className="workspace">
    <a className="skip-link" href="#main-content">Skip to content</a>
    <aside className="sidebar" onKeyDown={event => {
      if (event.key === "Escape" && open) {
        setOpen(false); toggle.current?.focus();
      }
    }}>
      <div className="brand">
        <span className="brand-mark" aria-hidden="true">C</span>
        <div><strong>DwenTech <span>CPA</span></strong><small>Chief Product Architect</small></div>
        <button ref={toggle} className="menu-toggle" aria-expanded={open} aria-controls="primary-navigation"
          onClick={() => setOpen(!open)}><Icon name="menu" /><span>Menu</span></button>
      </div>
      <div className={`navigation-panel ${open ? "is-open" : ""}`} id="primary-navigation">
        <p className="nav-heading">Your workspace</p>
        <nav aria-label="Main navigation">
          {modules.map(item => <Link href={`/${item.slug}`} key={item.slug}
            aria-current={pathname === `/${item.slug}` ? "page" : undefined}
            onClick={() => {
              if (pathname === `/${item.slug}`) {
                setOpen(false);
                document.getElementById("main-content")?.focus();
              }
            }}>
            <Icon name={item.icon} />
            <span className="nav-label"><span>{item.name}</span>{item.slug && <small>Not available yet</small>}</span>
          </Link>)}
        </nav>
        <div className="sidebar-note"><Icon name="lock" /><div><strong>Local workspace preview</strong>
          <p>No live services connected.</p></div></div>
      </div>
    </aside>
    <div className="workspace-body">
      <header className="topbar">
        <div className="breadcrumb"><span>Workspace</span><span aria-hidden="true">/</span><strong>{current?.name ?? "Page not found"}</strong></div>
        <div className="session-state"><span className="preview-pill">Local preview</span><span>Not signed in</span></div>
      </header>
      <main id="main-content" tabIndex={-1}>{children}</main>
      <footer>Dwen Tech Ltd <span aria-hidden="true">·</span> CPA laboratory <span className="footer-right">Local preview · No live data</span></footer>
    </div>
  </div>;
}
