# B016 — Local sign-in/session and access-denied integration

**Date:** 20 October 2026 UTC  
**Authority:** User “Start B016”; existing local-only restrictions  
**Status:** Blocked for implementation pending the two local scope/transport decisions below  
**Executor:** Codex; Justice remains nominated technical authority

## Scope and dependency review

The unchanged build-order completion check is: **“Permitted sign-in journey works; direct API denial remains effective independently of the UI.”** See [build order](../../build-order.md), [work item](../planning/phase-1-work-items.md#b016) and F01/F02 in the [feature specification](../../feature-spec.md).

B015 is accepted and Done. B013 permissions and B014 opaque server-stored sessions are accepted for their local scopes. B014 explicitly deferred real human login, browser cookies/storage, sign-in UI and provider integration to a separately approved approach. O-04 remains partly resolved. Starting B016 selects the task; it does not select an identity provider or custom password/recovery system.

Local source inspection confirms:

- The normal FastAPI app exposes status, health and OpenAPI only. It has no login/session/record endpoints.
- `backend/app/sessions.py` validates persisted opaque Bearer sessions and delegates record permissions to B013. Missing store wiring fails closed. Session issuance is internal and requires verified identity; it must not become an unauthenticated normal-app login endpoint.
- B014's isolated test harness supplies actual PostgreSQL stores and synthetic identities; it tests direct HTTP denial independently of UI.
- The B015 shell currently shows “Not signed in” as static preview context. It reads no session and loads no protected records.
- No persistent application PostgreSQL destination is retained. Existing disposable-database tooling can support a separately approved local integration harness.

## Decisions requested

1. **Local scope:** approve a clearly labelled synthetic sign-in journey available only in an isolated local test harness, backed by actual PostgreSQL sessions and permissions. Real login remains unavailable in the normal app. Alternative: prepare the proposal only.
2. **Browser transport:** approve a same-origin server layer using an HttpOnly, SameSite=Strict cookie, server-side Bearer forwarding and origin checks on state-changing requests. No localStorage tokens. Loopback HTTP is test-only; future HTTPS deployment requires Secure cookies and separate deployment verification.

Both answers are pending. These questions are needed because the approved [B014 policy](../planning/B014-local-session-policy.md) explicitly leaves browser integration unapproved. Neither question grants GitHub, downloads, cloud/provider calls, real-account creation or live-client data use.

## Concrete implementation proposal

After approval, keep synthetic identity issuance in a separate test harness, absent from normal application routes and startup. Do not add a normal-app mock-login toggle or trust a browser-supplied user/role/client header. Use disposable synthetic accounts and records with the existing approved matrix; no new business grants.

Use a same-origin server boundary to keep credentials out of client JavaScript. Forward only the required credential to a fixed trusted loopback backend, with no arbitrary proxy destination. Do not follow backend redirects or expose backend token responses to the browser. Protect state-changing requests with exact origin checks; use POST for login/logout, no-store responses and a host-only cookie. Do not introduce wildcard CORS.

The UI should distinguish unauthenticated, authenticated synthetic fixture, session expired/revoked, access denied/not found, and service unavailable. Do not render restricted content before permission checks. Preserve B013's 403/404 disclosure rules. Use a fixed internal return path rather than accepting arbitrary redirects. A service outage must not appear as successful logout or a signed-in fallback.

Keep B014's 30-minute idle and 8-hour absolute expiry, no refresh and immediate revocation semantics. Browser cookie lifetime must not extend backend lifetime. Logout should revoke the current backend session and clear the local cookie; expiry/revocation must remove protected UI state. Privileged operations remain denied pending MFA.

## Planned verification — not executed

- Run existing backend contract, permissions and session checks as relevant to changed code.
- Exercise actual browser → same-origin server → backend → disposable PostgreSQL session/permission flow.
- Verify valid synthetic sign-in and permitted synthetic record access, logout/replay, expired/revoked session and disabled membership.
- Verify direct API calls without credentials, with malformed credentials and with another client's valid session fail independently of UI visibility.
- Verify 403/404 states disclose no restricted record title/content; 503 shows unavailable, not empty or authenticated success.
- Check cookie attributes, no raw credential in HTML/client state/URLs/logs, origin rejection, safe return navigation and no normal-app synthetic issuance endpoint.
- Check keyboard focus and responsive sign-in/denial states; compile/typecheck the frontend.
- Clean up disposable database/server fixtures and record actual results and limitations.

## Acceptance and boundary

No B016 acceptance check has passed. A synthetic journey would establish local browser/session/permission integration only; it cannot prove real human identity verification. Acceptance of that limited deliverable would need to state its local scope explicitly, with real sign-in and full AC-F01-01 assurance deferred.

[Pre-edit snapshot](B016-before.zip) preserves the tracker and documentation index. No application source, dependencies, running service or database changed during preparation. B004 remains Blocked; B005/B007 retain their review boundaries. B017 is Not started.
