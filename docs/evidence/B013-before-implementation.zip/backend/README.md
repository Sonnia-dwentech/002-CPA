# CPA Local Foundation API — B011

This is a minimal local FastAPI application, not the completed CPA backend.
It uses the already-installed Python 3.14.8 environment; no packages were installed
or downloaded for B011. See [requirements-local.txt](requirements-local.txt) for
the observed direct/framework versions exercised by the tests. This is not a
complete dependency lock or proof of a clean-machine installation.

## Run locally

In PowerShell:

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B run_local.py
```

The launcher binds only to `127.0.0.1:8000`. Stop it with Ctrl+C.
If that port is occupied, select another local port:

```powershell
python -B run_local.py --port 8001
```

In a second PowerShell terminal:

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/health'
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/openapi.json'
```

These requests use loopback only. They do not connect to GitHub or an external
provider. No service is left running by the test suite.

## Contract

| Request | Result |
| --- | --- |
| `GET /health` | HTTP 200, `{"status":"ok"}`, `Cache-Control: no-store` |
| `GET /openapi.json` | Generated local API schema; no external documentation assets |
| Unknown route | HTTP 404, generic `not_found` error |
| Unsupported method on `/health` | HTTP 405, generic error and `Allow` header |
| Invalid validated request | HTTP 422, generic `validation_error`; no submitted values echoed |
| Unexpected application exception | HTTP 500, generic `internal_error`; no exception text returned |

Error body:

```json
{"error":{"code":"not_found","message":"Resource not found."}}
```

The health check means **process liveness only**. It does not check or claim database,
identity, provider, migration, deployment or overall product readiness. The app has
no business-data routes. Validation and exception behaviour is tested through
test-only routes added to isolated app instances; those routes are not exposed by
the actual application or its OpenAPI schema.

Browser `/docs` and `/redoc` are disabled, so viewing a schema does not require CDN
assets. Debug mode is off. The local launcher disables access logging, proxy-header
trust and the server-version header. It uses critical-only server logging to avoid
printing raw request/exception details. Proper redacted operational logging is
still B017 work; this launcher is not a production logging/deployment design.

The app does not load `.env`, connect to a database, initialise credentials or call
a model. Existing configuration templates remain future configuration guidance,
not active protection mechanisms. No authentication or CORS policy is implemented;
keep this process local and do not expose it through public tunnels or deployment.

## Verify

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B -m unittest discover -s tests -v
```

Tests use Python's standard-library runner, direct ASGI requests and a short-lived
loopback server. No pytest/httpx installation is needed. The startup test chooses
an available local port, starts the actual launcher without a visible child
console, checks the health response and stops the child in a cleanup block.
All inputs and secret canaries are synthetic.

This provides B011 component startup/health/error evidence, not B010's deferred
complete fresh-setup walkthrough. B012 now has a separately authorised disposable PostgreSQL check workflow below. B005's formal technical review and other G0-L deferrals remain
outstanding. See [B011 evidence](../docs/evidence/B011-local-api.md) and
[current progress](../progress.md) for actual acceptance status.


## B012 disposable PostgreSQL migration checks

The user lifted the setup deferral for this local scope on 20 October 2026. Uses installed psycopg 3.3.6 and an existing Docker `postgres:17` image. No downloads or installs are performed. Start the installed Docker Desktop engine first if stopped; this may require local permissions.

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B check_local_database.py
```

The script targets only the local Windows Docker named pipe, inspects the existing image and runs its immutable ID with `--pull=never`. Each invocation creates a uniquely named container, ephemeral loopback port, random password passed through the child environment, and tmpfs storage. The script never selects an existing database/container. Credentials are not saved in source or printed. It stops/removes its test container in cleanup; Docker Desktop itself remains running.

`app/database.py` supplies local connectivity and an atomic batch migration runner with transaction-scoped advisory locking, a history-prefix check and SHA-256 checksums. Ordered SQL files live in `migrations/`. The first migration creates only the empty `cpa` namespace; bookkeeping lives in `cpa_meta.schema_migrations`. Do not edit applied migrations. Add transaction-compatible SQL in a new numbered file; transaction control and nontransactional DDL are outside this runner's supported contract.

The checks demonstrate rollback on constraint failure, recovery by correcting an unapplied migration, preservation of synthetic data after transaction failure, and an explicit test-only rollback to the baseline. They do not prove backup/restore or production disaster recovery. Destructive down-migrations need their own data-loss assessment; there is no automatic general rollback command.

Fixture manifest: `B012-synthetic-probe`, version 1, created by Codex for this task; entirely invented integer pair `(1, 7)` in `cpa.recovery_probe`, temporary test migration 0002. Owner is the B012 executor. Storage is only the generated container's tmpfs; cleanup occurs at the end of each run, with the fixture removed earlier by the tested rollback. Expected outcomes are defined in the script and [B012 evidence](../docs/evidence/B012-local-database.md).

The generated PostgreSQL bootstrap role is privileged solely inside this disposable instance. It is not an approved application runtime role or evidence of least-privilege access. B013/B014 still need user/role/tenancy/session decisions; the API's public health remains liveness-only. No persistent development database or application-wide database readiness is claimed.
