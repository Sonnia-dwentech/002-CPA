# B014 — Local Authentication and Session Preparation

**Date:** 20 October 2026 UTC  
**Authority:** User “Start B014”, under G0-L and existing local-only restrictions  
**Status:** Blocked for implementation; local contract and verification preparation delivered  
**Executor:** Codex; Justice remains nominated technical authority

## Scope and dependency findings

[B014](../../build-order.md) requires approved backend authentication/session validation. Its unchanged completion check is: “AC-F01-01 passes; invalid/expired credentials cannot obtain protected responses.”

The [work item](../planning/phase-1-work-items.md#b014) depends on B013 and decisions about identity/session validation, expiry/revocation and privileged MFA. B012 is accepted and Done. B013's [recommended matrix](../planning/B013-recommended-access-matrix.md) is proposed, not approved. [O-04](../../decisions.md#o-04) and [ADR-002](../adr/002-identity-roles-tenancy.md) leave the identity approach and session policy open.

The user selected B014, permitting this independent local preparation. That selection does not approve the B013 matrix, choose an identity provider or authorise external identity calls. No authentication implementation, account creation, credential generation or new database work occurred. B015 remains unstarted.

## Decisions Justice needs to record

| Decision | Concrete outcome required | Current state |
| --- | --- | --- |
| B013 policy and user-reference boundary | Approve/amend identity mapping, membership, enabled status and access rules; record applicable B006 review | Awaiting review of access matrix v0.1 |
| Identity approach | Managed identity integration or application-managed identity; selected authority and account lifecycle | Unselected; no vendor or custom password/recovery system adopted |
| Credential validation | Accepted credential type and transport, trusted issuer/audience or server session lookup, validation configuration and failure handling | Unselected; request headers cannot supply trusted user/role/client fields |
| Session lifetime | Exact idle/absolute expiry policy, refresh/rotation behaviour, clock handling and reauthentication requirements | Unset; no invented durations |
| Logout and revocation | Which sessions logout ends; effect of account suspension, membership removal and password/security changes | B013 proposes current-state checks; implementation policy unapproved |
| Privileged MFA | Which actions/roles require MFA, how assurance is verified and when fresh authentication is needed | Unselected; GitHub MFA is not application MFA |
| Browser/session protections | Cookie or bearer approach, applicable request-forgery protection, allowed origins and local-to-deployed differences | Unselected; no wildcard origins or browser credential storage chosen |
| Failure and disclosure contract | Public status/error behaviour for invalid credentials and unavailable validation; safe diagnostics | Proposal below; technical approval needed |
| Local verification boundary | Isolated synthetic validator fixtures and a protected test-only route; later actual identity integration evidence | Proposed; no mock login added to the application |

These decisions can be reviewed without GitHub. If the selected implementation needs downloads, new packages, external discovery/key retrieval or provider accounts, identify that requirement separately before proceeding. Local-only does not silently permit those operations.

## Proposed backend boundary for review

Keep credential verification distinct from record authorisation:

1. A validator accepts only the approved credential form. It validates the credential using the approved method before creating any trusted identity context.
2. Resolve the verified identity to the B013 application user reference and check that the account and required membership remain active.
3. Pass a minimal trusted context to B013's permission evaluator. Successful authentication alone never grants access to a resource.
4. Enforce the boundary on protected requests regardless of UI state. Public B011 `/health` remains process liveness and cannot be used as proof that protected requests are authenticated.
5. Invalid, expired, revoked or unverifiable credentials never return protected content. Validation infrastructure failure must fail closed; there is no fallback actor or administrator.
6. Never log or echo credential values, identity-provider secrets or submitted private payloads. The approved application logging policy governs diagnostic events.

Proposed public response distinction: generic 401 for missing/invalid/expired/revoked credentials; generic 503 when the selected validation dependency is unavailable, with no protected response; apply B013's approved 403/404 rules only after successful authentication. This is a proposed contract, not existing behaviour or a claimed vendor capability.

The actual adapter must follow the selected method's complete verification rules. A session lookup and a signed-token verifier are alternatives, not interchangeable pseudovalidation. Do not implement a stub that accepts any token, a debug login, a trusted user-ID header or a mock validator accessible through normal application configuration.

## Local preparation versus execution

This report prepares the contract and test cases independently of B013. Implementation of identity-to-user mapping and account/membership checks needs B013's approved references and rules. Full authentication-to-record enforcement needs its implemented policy boundary.

After task-level approval, isolated test fixtures may exercise denial and context-mapping behaviour without contacting a provider. Fixtures must be available only through the test harness; the normal app must not expose a switch to authenticate as an arbitrary user.

Mocked tests alone cannot establish real signature verification, session revocation, MFA or provider integration. Record any selected-method checks separately and do not mark the unchanged acceptance criteria passed from mocks alone.

## Planned verification — none executed

| Case | Required evidence after the contract is approved |
| --- | --- |
| Missing credential | Protected request denied; response contains no protected data |
| Malformed, wrong-type or tampered credential | Denied before trusted identity context is produced |
| Wrong issuer/audience/key or unknown session, as applicable | Denied by the selected validation method |
| Expired or not-yet-valid credential, as applicable | Boundary cases checked against the approved time rules |
| Revoked credential/session or disabled account | Denied despite a previously successful sign-in |
| Valid credential with unmapped user | Denied; no automatic privileged account creation |
| Valid, mapped, active user | Correct trusted context, followed by B013 record permission checks |
| Forged role/client/user fields | No privilege or membership change |
| Privileged action without required MFA assurance | Denied or requires the approved reauthentication path |
| Validation dependency unavailable | Fail closed; generic approved failure response |
| Refresh/logout replay | Behaviour matches the approved invalidation/rotation policy |
| Credential/error canaries | No token/private payload exposed through responses or diagnostic output |
| Direct API request bypasses UI | Same authentication and permission enforcement |

Fixture requirements: wholly synthetic identities and non-live credentials; manifest recording the selected method, schema, version, creator, expected outcomes, isolated storage and cleanup. Use test-generated signing keys only if that method is selected. No real sessions or client data. No fixtures or persistent stores were created in this preparation.

AC-F01-01 also mentions the approved sign-in interface. Backend denial belongs here; the sign-in/access-denied UI is integrated at B016. Backend checks cannot claim that future UI journey passed. The final acceptance record must state this component boundary explicitly.

## Completion path and preservation

1. Record Justice's B013 matrix decision and relevant technical review.
2. Record B014's identity/session/MFA choices above.
3. Implement the approved backend adapter and user-policy integration using an authorised local test destination.
4. Run actual selected-method validation and negative tests, then review evidence against the unchanged B014 completion check.

B014 is started but Blocked for implementation. No requirement is waived and no task is marked Done by this preparation. B013 remains Blocked; B012 remains Done; B015 is not started.

[Pre-edit snapshot](B014-before.zip) and [input hashes](B014-input-hashes.json) preserve existing records. Only progress.md and the documentation index change; this report and preservation files are new. Existing code, source documents, prior evidence and task definitions remain unchanged. No GitHub, installs, external services or database execution occurred.
