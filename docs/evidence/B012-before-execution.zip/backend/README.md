# CPA Local Foundation API — B011

This is a minimal local FastAPI application, not the completed CPA backend.
It uses the already-installed Python 3.14.8 environment; no packages were installed
or downloaded for B011. See [requirements-local.txt](requirements-local.txt) for
the observed direct/framework versions exercised by the tests. This is not a
complete dependency lock or proof of a clean-machine installation.

## Run locally

In PowerShell:

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B run_local.py
```

The launcher binds only to `127.0.0.1:8000`. Stop it with Ctrl+C.
If that port is occupied, select another local port:

```powershell
python -B run_local.py --port 8001
```

In a second PowerShell terminal:

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/health'
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/openapi.json'
```

These requests use loopback only. They do not connect to GitHub or an external
provider. No service is left running by the test suite.

## Contract

| Request | Result |
| --- | --- |
| `GET /health` | HTTP 200, `{"status":"ok"}`, `Cache-Control: no-store` |
| `GET /openapi.json` | Generated local API schema; no external documentation assets |
| Unknown route | HTTP 404, generic `not_found` error |
| Unsupported method on `/health` | HTTP 405, generic error and `Allow` header |
| Invalid validated request | HTTP 422, generic `validation_error`; no submitted values echoed |
| Unexpected application exception | HTTP 500, generic `internal_error`; no exception text returned |

Error body:

```json
{"error":{"code":"not_found","message":"Resource not found."}}
```

The health check means **process liveness only**. It does not check or claim database,
identity, provider, migration, deployment or overall product readiness. The app has
no business-data routes. Validation and exception behaviour is tested through
test-only routes added to isolated app instances; those routes are not exposed by
the actual application or its OpenAPI schema.

Browser `/docs` and `/redoc` are disabled, so viewing a schema does not require CDN
assets. Debug mode is off. The local launcher disables access logging, proxy-header
trust and the server-version header. It uses critical-only server logging to avoid
printing raw request/exception details. Proper redacted operational logging is
still B017 work; this launcher is not a production logging/deployment design.

The app does not load `.env`, connect to a database, initialise credentials or call
a model. Existing configuration templates remain future configuration guidance,
not active protection mechanisms. No authentication or CORS policy is implemented;
keep this process local and do not expose it through public tunnels or deployment.

## Verify

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B -m unittest discover -s tests -v
```

Tests use Python's standard-library runner, direct ASGI requests and a short-lived
loopback server. No pytest/httpx installation is needed. The startup test chooses
an available local port, starts the actual launcher without a visible child
console, checks the health response and stops the child in a cleanup block.
All inputs and secret canaries are synthetic.

This provides B011 component startup/health/error evidence, not B010's deferred
complete fresh-setup walkthrough. Database setup remains deferred; B012 must not
start automatically. B005's formal technical review and other G0-L deferrals remain
outstanding. See [B011 evidence](../docs/evidence/B011-local-api.md) and
[current progress](../progress.md) for actual acceptance status.
