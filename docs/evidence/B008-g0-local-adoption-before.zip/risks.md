# CPA Risk Register

**Version:** 0.7 · **Updated:** 20 October 2026 UTC · **Status:** Local record structure and workflow accepted under B003

Authoritative local risk record. All risks below are **Open** potential risks, not observed application defects. Likelihood, impact ratings and dates are unassessed; named assignments are not recorded. Roles identify required authorities. Mitigations are planned and require evidence, not claimed implemented controls. RK IDs are separate from B002 source-conflict R IDs.

[Progress](progress.md) owns actual blockers/status; [decisions](decisions.md) owns pending choices. Task links refer to build definitions; none authorise execution.

| ID | Risk | Responsible role | Decision / tasks | Source | Mitigation / closure evidence required |
| --- | --- | --- | --- | --- | --- |
| RK-01 | Scope expands before MVP acceptance | CEO/product owner and Justice | [O-01](decisions.md#o-01); [B007](build-order.md), [B008](build-order.md), [B056](build-order.md) | [D006](CPA_Development_Handover_Pack_v1/docs/006-development-roadmap-sprint-backlog.md) | Approve included/deferred scope and verify gate compliance. |
| RK-02 | Unsupported claims or false research coverage | Product/research owner and Justice | [O-06](decisions.md#o-06); [B029](build-order.md), [B040](build-order.md), [B082](build-order.md) | [D004](CPA_Development_Handover_Pack_v1/docs/004-ai-agents-and-intelligence-framework.md) | Verify provenance, freshness and missing-evidence labels with reviewed outputs. |
| RK-03 | Bias or unjustified scoring precision | Product owner and Justice | [O-10](decisions.md#o-10); [B029](build-order.md), [B041](build-order.md), [B057](build-order.md) | [D004](CPA_Development_Handover_Pack_v1/docs/004-ai-agents-and-intelligence-framework.md) | Approve scoring and missing-rating rules; verify scenarios and human review. |
| RK-04 | Uncontrolled model or worker costs | Justice and budget owner | [O-07](decisions.md#o-07); [B019](build-order.md), [B029](build-order.md), [B037](build-order.md) | [D007](CPA_Development_Handover_Pack_v1/docs/007-security-data-and-ai-governance.md) | Approve limits and verify enforcement/retry handling before live calls. |
| RK-05 | Source licence or client IP misuse | Product/research owner and Justice | [O-06](decisions.md#o-06); [B006](build-order.md), [B029](build-order.md), [B082](build-order.md) | [D007](CPA_Development_Handover_Pack_v1/docs/007-security-data-and-ai-governance.md) | Record rights and verify permitted ingestion, storage and use. |
| RK-06 | Secrets or sensitive information exposure | Justice | [O-12](decisions.md#o-12); [B006](build-order.md), [B017](build-order.md), [B101](build-order.md) | [D007](CPA_Development_Handover_Pack_v1/docs/007-security-data-and-ai-governance.md) | Verify secrets handling, redaction and privacy boundaries. |
| RK-07 | Cross-client or unauthorised record access | Justice and product owner | [O-04](decisions.md#o-04); [B005](build-order.md), [B013](build-order.md), [B016](build-order.md), [B101](build-order.md) | [D007](CPA_Development_Handover_Pack_v1/docs/007-security-data-and-ai-governance.md) | Approve access rules; verify negative authorisation and isolation cases. |
| RK-08 | Prompt injection from untrusted content | Justice | [O-06](decisions.md#o-06); [B029](build-order.md), [B037](build-order.md), [B073](build-order.md) | [D004](CPA_Development_Handover_Pack_v1/docs/004-ai-agents-and-intelligence-framework.md) | Test content/instruction separation and tool permission boundaries. |
| RK-09 | Premature service/agent complexity | Justice | [O-03](decisions.md#o-03); [B005](build-order.md), [B029](build-order.md) | [D003](CPA_Development_Handover_Pack_v1/docs/003-system-architecture-and-technology-specification.md) | Approve minimal ADR boundaries; verify maintainability in review. |
| RK-10 | Missing independent review or inferred release approval | Justice and CEO | [O-02](decisions.md#o-02); [B004](build-order.md), [B008](build-order.md), [B104](build-order.md) | [D010](CPA_Development_Handover_Pack_v1/docs/010-developer-working-agreement-and-assistant-instructions.md) | Record eligible human reviews and explicit gate acceptance. |
| RK-11 | Data loss or failed recovery | Justice | [O-16](decisions.md#o-16); [B023](build-order.md), [B100](build-order.md), [B102](build-order.md) | [D009](CPA_Development_Handover_Pack_v1/docs/009-deployment-operations-guide.md) | Approve recovery targets and demonstrate restore/rollback. |
| RK-12 | Illustrative UI metrics appear operational | Product owner and Justice | [O-11](decisions.md#o-11); [B007](build-order.md), [B015](build-order.md), [B056](build-order.md) | [D005](CPA_Development_Handover_Pack_v1/docs/005-ui-ux-design-specification.md) | Verify truthful unavailable/draft states and rendered journeys. |
| RK-13 | Document drift or unsupported completion claims | Justice; executor maintains evidence | [O-18](decisions.md#o-18); [B003](build-order.md), [B007](build-order.md) | [D006](CPA_Development_Handover_Pack_v1/docs/006-development-roadmap-sprint-backlog.md) | Verify linked records, counts and preserved history on handoff. |
| RK-14 | Remote activity contrary to user deferral | Justice and user | [O-02](decisions.md#o-02); [B004](build-order.md) | [D010](CPA_Development_Handover_Pack_v1/docs/010-developer-working-agreement-and-assistant-instructions.md) | Keep B004 deferred until explicit changed authority or recorded approved replan. |

## Maintenance and history

Review relevant risks before each selected task and at handoff. Use Open, Mitigating, Accepted or Closed. Record date, assessment, authority/owner, action and evidence for changes. Accepted requires explicit residual-risk acceptance; Closed requires demonstrated closure evidence. Reopen if later evidence invalidates closure. An actual blocker belongs in progress with task, impact, authority and unblock condition. Regular cadence remains O-18/B007.

20 October 2026 UTC: RK-01–RK-14 registered Open from linked source requirements; RK-14 also reflects the user's current local-only instruction. No mitigation verified. See [B003 report](docs/evidence/B003-records-setup.md).

20 October 2026 UTC: User accepted the B003 local record structure and maintenance workflow. This accepts the register process; all RK risks remain Open and mitigations unverified.

20 October 2026 UTC: B004 local preflight recorded the actual authority blocker in [progress](progress.md) and [B004 report](docs/evidence/B004-local-preflight.md). RK-10/RK-14 remain Open; no GitHub controls verified and no remote activity performed.

20 October 2026 UTC: Under the explicit B005 local exception, [four proposed ADRs](docs/adr/README.md) document design options relevant to RK-06/RK-07/RK-09/RK-10/RK-11/RK-14. This is review preparation, not implemented mitigation or risk acceptance. All risks remain Open; remote alignment and eligible repository review remain unverified.

20 October 2026 UTC: [B006 draft policy](docs/policies/allowed-data-and-test-fixtures.md) documents proposed boundaries relevant to RK-02/RK-05/RK-06/RK-07/RK-08/RK-11/RK-12. No controls implemented or verified; all risks remain Open.

20 October 2026 UTC: B007 [work-item pack](docs/planning/phase-1-work-items.md) and [operations worksheet](docs/planning/phase-1-design-operations.md) expose readiness gaps relevant to RK-01/RK-04/RK-09/RK-10/RK-11/RK-12/RK-13/RK-14. Planned actions are not verified mitigations; risk states unchanged.

20 October 2026 UTC: [B008 G0 assessment](docs/evidence/B008-g0-readiness-assessment.md) records Hold for actual prerequisite/sign-off gaps relevant to RK-09/RK-10/RK-13/RK-14. Gate remains closed; no risk closure or residual-risk acceptance inferred.
