# CPA — Local Working Project

## Local check runner — B020 preparation

From this project root, run
`.\backend\.venv312\Scripts\python.exe -B scripts/check_local_ci.py`.
The local checks pass, including backend/runner tests and both frontend type
checks. [Coverage and evidence](docs/evidence/B020-local-checks.md) explain the
limited syntax/secret/dependency checks. B020 is approved and Done under the user-approved
local-only scope. GitHub remains deferred; [RCI-01](docs/planning/remote-ci-handoff.md)
retains required remote CI and merge verification before remote collaboration/merge or release.

**Organisation:** Dwen Tech Ltd  
**Classification:** Confidential — Internal  
**Project:** Chief Product Architect AI Laboratory

This is the user-selected local CPA project. It currently contains source material, planning documents and local evidence. A minimal local foundation API is present; no complete product or verified remote checkout is established by this folder.

## Start here

1. Read [progress.md](progress.md) for current task status, authorisation and handoff.
2. Read [build-order.md](build-order.md) for task definitions, dependencies and gate boundaries.
3. Consult [decisions.md](decisions.md) and [risks.md](risks.md) before resolving design questions or starting affected work.
4. Use the [documentation index](docs/README.md) for source documents, ADRs, policy and evidence; use [project layout](docs/project-layout.md) to distinguish existing files from proposed future application paths.

Product context is in [blueprint.md](blueprint.md); behaviour and acceptance criteria are in [feature-spec.md](feature-spec.md). Document existence does not establish implementation or technical approval.

## Current working boundary

[G0-L v0.1](docs/planning/G0-local-only-proposal.md) was adopted and [reassessed](docs/evidence/B008-g0-local-reassessment.md) for separately selected local work. All GitHub connections, remote operations, live services, real-client data and deployment remain deferred. Task-specific decisions still apply; no blanket Phase 1 execution authority is implied. Current statuses belong in progress.md.

Preserve the original handover folder, Word documents, archive and UI reference. Original pack instructions describe an earlier proposed remote workflow; the user's current local-only instruction governs this project. Do not interpret original GitHub/Render setup text as authority to connect or provision services.

Justice is the user-nominated interim accountable implementation owner and product/scope approver. Codex may execute selected local tasks; this does not establish Justice's personal acceptance or independent human review. Refer to the ledgers for actual approval evidence.

## Setup and execution

[B010 local setup preparation](docs/local-setup.md) records provisional tooling and deferred fresh-setup verification. [Backend instructions](backend/README.md) cover the loopback API on port 8000; accepted B012–B014 evidence covers disposable local PostgreSQL, access boundaries and synthetic sessions.

The frontend uses http://127.0.0.1:3000/ when started. [Frontend instructions](frontend/README.md) cover the B015 responsive navigation shell, cache-only dependencies and run/build commands. B016's isolated synthetic browser integration and B017's local audit scope are accepted. B018's [mock AI adapter](docs/evidence/B018-local-ai-adapter.md) is approved and accepted, with 15 adapter tests and all 42 backend tests passing. Real sign-in and application data remain unconnected. Fresh isolated setup is reserved for B027 before G1.

On the current workstation (`C:\Users\Win11\Documents\002 CPA`), the user subsequently authorised Python dependency installation. The working environment is `backend/.venv312` (Python 3.12.14), with original dependency pins and Windows psycopg binary support. All 42 backend tests pass and `pip check` is clean. See the [backend guide](backend/README.md) for commands. Earlier machine paths/tool inventories and missing-package observations are historical. PostgreSQL integration checks have not been rerun in this session.

Use the [allowed-data and test-fixture policy](docs/policies/allowed-data-and-test-fixtures.md) before future test-data work. Local examples must not be confused with live research or client records.


B019 [local AI configuration and usage controls](docs/evidence/B019-local-ai-controls.md) are approved and Done for the local scope. All 54 backend tests pass, including 12 B019 tests. Live calls remain disabled even with complete configuration; no live budget or quota policy is selected. B020 local checks are approved and Done under the revised local scope.


B021 local dashboard query service is implemented for approved synthetic reference counts. All 68 backend tests pass; actual PostgreSQL verification remains blocked by the unavailable Docker runtime. No business metrics or dashboard UI were enabled. See [B021 evidence](docs/evidence/B021-local-dashboard.md).


Current B021 update — 21 October 2026: actual PostgreSQL 17.11 verification passed all 15 harness checks after Docker recovery and approved image download; full local checks passed. Earlier unavailable-runtime statements are historical. B021 is In review for local acceptance; B022 unstarted. The test container was already removed before the user requested no cleanup; retain future test containers and adjust the automatic-cleanup harness before reuse. See the B021 evidence and progress tracker.
