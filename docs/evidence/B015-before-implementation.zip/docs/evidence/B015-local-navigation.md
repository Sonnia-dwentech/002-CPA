# B015 — Local Responsive Navigation Shell

**Date:** 20 October 2026 UTC  
**Authority:** User “Start B015”; G0-L and local-only restrictions  
**Status:** Blocked pending offline-install and local design-baseline choices  
**Executor:** Codex; no independent review inferred

## Scope and findings

[B015](../../build-order.md) requires a responsive Next.js navigation shell. Its completion check is: “Routes/state labels reflect delivered scope; keyboard/focus checks pass; no fake service availability.”

B014 is accepted and Done. [O-11](../../decisions.md#o-11) and the [design worksheet](../planning/phase-1-design-operations.md) leave final route labels, design tokens/assets and unavailable-navigation treatment unresolved. The user has been asked to approve:

1. Dependency installation using the existing local npm cache only, with network access and install scripts disabled.
2. A small documented token set derived from the supplied UI reference, source-document navigation labels and visible “Not available yet” labels.

Both answers are pending. No dependency installation or frontend implementation has occurred. The current backend remains available at port 8000; it is not the Next.js frontend.

## Read-only local tooling evidence

- Node 24.21.0 and npm 11.19.0 reported their versions; these were previously approved provisional tooling.
- npm cache lists Next.js 16.3.8, React/React DOM 19.3.0, TypeScript 6.0.3 and 7.0.2, React types 19.3.0 and Node types 24.19.1 tarballs.
- Cache entries are not proof of a complete compatible install. A targeted SWC cache query returned no entries; native compiler availability remains unverified.
- No registry request, package download, install, GitHub or external provider operation was performed. An approved offline install must fail rather than fall back to fetching missing dependencies.

## Proposed route and availability plan

Use [D005](../../CPA_Development_Handover_Pack_v1/docs/005-ui-ux-design-specification.md) for labels. The mockup's alternate labels, counts, user photo and operational badges are illustrative and do not establish actual data or service readiness.

| Route | Source label | Proposed content/state |
| --- | --- | --- |
| `/` | Command Centre | Local shell introduction and explicit unavailable-data state; no fabricated metrics |
| `/opportunity-scanner` | Opportunity Scanner | Not available yet; no scan action |
| `/idea-studio` | Idea Studio | Not available yet; no save/analyse action |
| `/academic-research` | Academic Research | Not available yet; no source fetching |
| `/discovery-enquiries` | Discovery Enquiries | Not available yet; no client data or intake action |
| `/stress-testing` | Stress Testing | Not available yet; no scenario execution |
| `/portfolio` | Portfolio | Not available yet; no invented portfolio |
| `/voice-studio` | Voice Studio | Not available yet; no microphone access |
| `/business-modelling` | Business Modelling | Not available yet; no calculated figures |
| `/reports` | Reports | Not available yet; no generated export |
| `/knowledge-hub` | Knowledge Hub | Not available yet; no operational search |
| `/settings` | Settings | Not available yet; no credential, membership or configuration changes |

Links may navigate to explanatory unavailable pages; their labels must not imply the underlying service works. The active Command Centre route is a shell view, not an operational dashboard. An unknown URL should produce a useful not-found state.

Header context: organisation/product name and “Local preview — not signed in”. Do not invent a current user, unread-notification badge or connected-account state. Search, geography and notifications have no implemented service and should not look operational. Real sign-in/access-denied integration remains B016.

## Proposed design and interaction baseline

- Preserve `UI.png` in place as reference; no crop of its fake metrics, logo recreation or external image/font requests.
- Derive explicit CSS tokens for navy navigation, blue active/focus state, neutral background, white panels, text/borders, spacing, radius and system typography. Record chosen values with the implementation after approval; do not claim they were supplied as exact source tokens.
- Desktop sidebar and light main content; on narrow screens use an accessible navigation toggle with an accurate expanded state, Escape dismissal and sensible focus return.
- Semantic navigation/main landmarks, a skip link, descriptive page titles, visible keyboard focus and current-page indication.
- No button starts an unavailable service. No mock record counts or “all systems operational” claims.

## Verification after approval and implementation

1. Resolve the local dependency set offline; if incomplete, report the missing package without downloads or script execution.
2. Verify Next.js startup and route/state rendering at a loopback-only frontend port. Keep the accepted backend separate.
3. Check each known route and unknown-route handling, availability labels and absence of fabricated data/provider controls.
4. Check keyboard navigation, skip link, focus visibility, mobile toggle and Escape/focus restoration.
5. Inspect desktop and narrow viewport layouts for clipping/overflow and readable labels. Record the actual tool/browser used and limits; static source inspection alone does not prove interactive checks passed.
6. Record results, exact local versions and clean stopping instructions. Do not claim B016 session integration or a full Command Centre implementation.

## Preservation and handoff

[Pre-edit snapshot](B015-before.zip) and [input hashes](B015-input-hashes.json) preserve existing records. Original source pack/UI reference and backend implementation remain unchanged. Only the tracker and documentation index are updated, with this report and preservation artifacts added.

B015 is started but implementation is awaiting the two explicit choices above. No acceptance check is claimed passed. B016 remains Not started.
