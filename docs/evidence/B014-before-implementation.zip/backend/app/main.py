"""Minimal local API: no database, credentials, provider calls or client data."""

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from starlette.exceptions import HTTPException


class HealthResponse(BaseModel):
    status: str


class ErrorDetail(BaseModel):
    code: str
    message: str


class ErrorResponse(BaseModel):
    error: ErrorDetail


def error_response(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={"error": {"code": code, "message": message}},
        headers={"Cache-Control": "no-store"},
    )


def create_app() -> FastAPI:
    application = FastAPI(
        title="CPA Local Foundation API",
        version="0.1.0",
        description=(
            "Local liveness only. Database, authentication, providers and "
            "deployment readiness are not implemented."
        ),
        debug=False,
        docs_url=None,
        redoc_url=None,
        openapi_url="/openapi.json",
        responses={
            404: {"model": ErrorResponse, "description": "Resource not found"},
            405: {"model": ErrorResponse, "description": "Method not allowed"},
            422: {"model": ErrorResponse, "description": "Invalid request"},
            500: {"model": ErrorResponse, "description": "Internal server error"},
        },
    )

    @application.exception_handler(HTTPException)
    async def http_error(_request: Request, exc: HTTPException) -> JSONResponse:
        known = {
            400: ("bad_request", "Invalid request."),
            401: ("unauthorized", "Authentication required."),
            403: ("forbidden", "Access denied."),
            404: ("not_found", "Resource not found."),
            405: ("method_not_allowed", "Method not allowed."),
            422: ("validation_error", "Invalid request."),
            429: ("too_many_requests", "Too many requests."),
            503: ("service_unavailable", "Service unavailable."),
        }
        code, message = known.get(
            exc.status_code, ("http_error", "Request could not be completed.")
        )
        response = error_response(exc.status_code, code, message)
        # Preserve protocol-required routing information, not arbitrary headers
        # or exception details that could contain private data.
        if exc.status_code == 405 and exc.headers:
            allowed = exc.headers.get("Allow")
            if allowed:
                response.headers["Allow"] = allowed
        return response

    @application.exception_handler(RequestValidationError)
    async def invalid_request(
        _request: Request, _exc: RequestValidationError
    ) -> JSONResponse:
        # Framework validation details can echo submitted values.
        return error_response(422, "validation_error", "Invalid request.")

    @application.exception_handler(Exception)
    async def unexpected_error(_request: Request, _exc: Exception) -> JSONResponse:
        return error_response(500, "internal_error", "Internal server error.")

    @application.get(
        "/health",
        response_model=HealthResponse,
        summary="Process liveness",
        description=(
            "Confirms the API process can answer. Does not check database, "
            "identity, providers or overall application readiness."
        ),
    )
    async def health() -> JSONResponse:
        return JSONResponse(
            content={"status": "ok"}, headers={"Cache-Control": "no-store"}
        )

    return application


app = create_app()
