# CPA Decision Register

**Version:** 0.8 · **Updated:** 20 October 2026 UTC · **Status:** Local record structure and workflow accepted under B003

This is the authoritative current decision register. [Progress](progress.md) owns task status; [build order](build-order.md) owns scope and order; [risks](risks.md) owns risk records. [B002](docs/evidence/B002-baseline-reconciliation.md) preserves conflict dispositions and explicit user answers. Roles below identify required authority, not accepted personal assignments. Dates and named assignees remain unset.

## Maintenance

Use Open, Partly resolved, Resolved or Superseded. Record the exact decision, authority, date, evidence, affected tasks and consequences before marking Resolved. Preserve superseded outcomes in dated history and link replacement ADRs. Unknown values are not unlimited or approved. Review dependent task readiness after changes; drafting a decision never grants approval.

## Current decisions

<a id="o-01"></a>
### O-01 — Scope, team clarification and priorities

- **State:** Partly resolved; scope/priorities open.
- **Required authority:** CEO/product owner and Justice.
- **Checkpoint / affected tasks:** [B002](build-order.md), [B007](build-order.md)–[B008](build-order.md).
- **Evidence / limits:** User confirmed human developer with AI assistance in B002.

<a id="o-02"></a>
### O-02 — Repository access, protections and reviewer workflow

- **State:** Open.
- **Required authority:** Justice.
- **Checkpoint / affected tasks:** [B004](build-order.md).
- **Evidence / limits:** User defers all GitHub activity; B004 local preflight is complete but current controls remain unverified. B004 is Blocked pending explicit read-only access authority or an approved recorded local-only replan; see [B004 report](docs/evidence/B004-local-preflight.md).

<a id="o-03"></a>
### O-03 — Architecture and hosting boundaries

- **State:** Open.
- **Required authority:** Justice.
- **Checkpoint / affected tasks:** [B005](build-order.md).
- **Evidence / limits:** Local B005 review prepared: [ADR-001 stack](docs/adr/001-core-stack.md), [ADR-003 environments](docs/adr/003-environments.md) and [ADR-004 boundaries](docs/adr/004-service-boundaries.md). Proposed options only; Justice decisions pending; remote alignment unverified.

<a id="o-04"></a>
### O-04 — Identity, role grants and client/record isolation

- **State:** Open.
- **Required authority:** Justice; product owner for business access.
- **Checkpoint / affected tasks:** [B005](build-order.md), [B013](build-order.md)–[B016](build-order.md).
- **Evidence / limits:** Local B005 [ADR-002 identity, roles and tenancy](docs/adr/002-identity-roles-tenancy.md) prepared. Identity/tenancy selection and product-owner permission grants remain undecided; no access assigned.

<a id="o-05"></a>
### O-05 — Jobs, recovery, cancellation and idempotency

- **State:** Open.
- **Required authority:** Justice.
- **Checkpoint / affected tasks:** [B029](build-order.md), [B035](build-order.md)–[B036](build-order.md).
- **Evidence / limits:** Not recorded.

<a id="o-06"></a>
### O-06 — Sources, licences, evidence grades and freshness

- **State:** Partly resolved; limited local policy user-approved, specialist and use-specific reviews open.
- **Required authority:** Product/research owner and Justice.
- **Checkpoint / affected tasks:** [B006](build-order.md), [B029](build-order.md), [B082](build-order.md).
- **Evidence / limits:** [B006 policy v0.2](docs/policies/allowed-data-and-test-fixtures.md) records user approval for limited local scope. Specialist review is deferred before affected implementation/data use; no source-specific rights, live-data permission or retention duration approved.

<a id="o-07"></a>
### O-07 — Model routing, credentials, budgets, quotas and limits

- **State:** Open.
- **Required authority:** Justice and authorised budget owner.
- **Checkpoint / affected tasks:** [B019](build-order.md), [B029](build-order.md), [B037](build-order.md)–[B039](build-order.md).
- **Evidence / limits:** Not recorded.

<a id="o-08"></a>
### O-08 — Export formats and private storage

- **State:** Open.
- **Required authority:** Product owner and Justice.
- **Checkpoint / affected tasks:** [B029](build-order.md), [B048](build-order.md), [B082](build-order.md).
- **Evidence / limits:** Not recorded.

<a id="o-09"></a>
### O-09 — Lifecycle, archive, versioning and review permissions

- **State:** Open.
- **Required authority:** Product owner and Justice.
- **Checkpoint / affected tasks:** [B029](build-order.md), [B043](build-order.md)–[B047](build-order.md), [B057](build-order.md).
- **Evidence / limits:** Not recorded.

<a id="o-10"></a>
### O-10 — Scoring, incomplete ratings and recommendation vocabulary

- **State:** Partly resolved; scoring/semantics open.
- **Required authority:** Product owner and Justice.
- **Checkpoint / affected tasks:** [B029](build-order.md), [B041](build-order.md), [B057](build-order.md), [B082](build-order.md).
- **Evidence / limits:** User confirmed Continue, Improve, Pivot, Pause, Stop in B002.

<a id="o-11"></a>
### O-11 — Navigation, design tokens/assets and phased content

- **State:** Open.
- **Required authority:** Product owner and Justice.
- **Checkpoint / affected tasks:** [B007](build-order.md), [B015](build-order.md).
- **Evidence / limits:** Not recorded.

- **B007 preparation:** [Design/operations approval worksheet](docs/planning/phase-1-design-operations.md) records proposed scope, prerequisites and unresolved choices. No design, numeric limit, named assignment or schedule approved by drafting.

<a id="o-12"></a>
### O-12 — Privacy, consent, rights, retention and sensitive inputs

- **State:** Partly resolved; limited local policy user-approved, specialist and use-specific reviews open.
- **Required authority:** CEO-designated policy owner and Justice.
- **Checkpoint / affected tasks:** [B006](build-order.md), [B067](build-order.md), [B101](build-order.md).
- **Evidence / limits:** [B006 policy v0.2](docs/policies/allowed-data-and-test-fixtures.md) records user approval for limited local scope. Specialist review is deferred before affected implementation/data use; no source-specific rights, live-data permission or retention duration approved.

<a id="o-13"></a>
### O-13 — Voice provider, supported interactions and transcript rules

- **State:** Open.
- **Required authority:** Product owner and Justice.
- **Checkpoint / affected tasks:** [B067](build-order.md).
- **Evidence / limits:** Not recorded.

<a id="o-14"></a>
### O-14 — Website intake, outbound channels and approval flow

- **State:** Open.
- **Required authority:** Product owner and Justice.
- **Checkpoint / affected tasks:** [B067](build-order.md).
- **Evidence / limits:** Not recorded.

<a id="o-15"></a>
### O-15 — Geography, languages, regions, coverage and maps

- **State:** Open.
- **Required authority:** Product/research owner and Justice.
- **Checkpoint / affected tasks:** [B082](build-order.md).
- **Evidence / limits:** Not recorded.

<a id="o-16"></a>
### O-16 — Performance, recovery targets, sizing and operating ceiling

- **State:** Open.
- **Required authority:** Justice and CEO.
- **Checkpoint / affected tasks:** [B007](build-order.md), [B023](build-order.md), [B100](build-order.md)–[B102](build-order.md).
- **Evidence / limits:** Not recorded.

- **B007 preparation:** [Design/operations approval worksheet](docs/planning/phase-1-design-operations.md) records proposed scope, prerequisites and unresolved choices. No design, numeric limit, named assignment or schedule approved by drafting.

<a id="o-17"></a>
### O-17 — Domain, support/incident ownership and release process

- **State:** Open.
- **Required authority:** CEO and Justice.
- **Checkpoint / affected tasks:** [B007](build-order.md), [B100](build-order.md)–[B104](build-order.md).
- **Evidence / limits:** Not recorded.

- **B007 preparation:** [Design/operations approval worksheet](docs/planning/phase-1-design-operations.md) records proposed scope, prerequisites and unresolved choices. No design, numeric limit, named assignment or schedule approved by drafting.

<a id="o-18"></a>
### O-18 — Estimates, assignments, cadence and success measures

- **State:** Partly resolved.
- **Required authority:** Justice and CEO.
- **Checkpoint / affected tasks:** [B003](build-order.md), [B007](build-order.md).
- **Evidence / limits:** Local record structure and maintenance workflow accepted by the user under B003 on 20 October 2026 UTC; estimates, assignments, cadence and success measures remain open.

- **B007 preparation:** [Design/operations approval worksheet](docs/planning/phase-1-design-operations.md) records proposed scope, prerequisites and unresolved choices. No design, numeric limit, named assignment or schedule approved by drafting.

## History

| Date | Authority | Outcome |
| --- | --- | --- |
| 20 October 2026 UTC | User B001 acceptance | Existing folder selected; GitHub deferred. See [B001](docs/evidence/B001-baseline-inventory.md). |
| 20 October 2026 UTC | User B002 answers | Human developer with AI assistance; Continue, Improve, Pivot, Pause, Stop. Broader scope/scoring rules remain open. See [B002](docs/evidence/B002-baseline-reconciliation.md). |
| 20 October 2026 UTC | User: “I have accepted B002” | Local reconciliation accepted; no architecture or gate approval inferred. |
| 20 October 2026 UTC | User: “Start B003” | Local records prepared for review; O-18 broader choices remain open. |

| 20 October 2026 UTC | User: “I accept the B003 local record structure and maintenance workflow.” | B003 Done; O-18 remains partly resolved because estimates, assignments, cadence and success measures remain open. |

| 20 October 2026 UTC | User: “Start B004” | Local preflight recorded; O-02 remains Open and B004 Blocked because the explicit GitHub deferral has not been lifted. No dependency replan made. |

| 20 October 2026 UTC | User controlled B005 exception | Local independent architecture review authorised while B004 stays Blocked. Four proposed ADRs prepared; O-03/O-04 remain Open. No Justice technical acceptance, provider adoption or gate approval inferred. |

| 20 October 2026 UTC | User: “I accept B005” | Local review accepted by user; Justice review evidence remains outstanding. O-03/O-04 remain Open; no architecture option or grant selected. |

| 20 October 2026 UTC | User: “Start B006” | Local policy draft prepared; O-06/O-12 remain Open. Earlier B004/B005 review requirements are retained; no live-data approval inferred. |

| 20 October 2026 UTC | User: “Approve B006” | Limited local policy accepted; B006 Done. Specialist reviews and architecture-dependent controls remain deferred, not approved by attribution. O-06/O-12 partly resolved only. |

| 20 October 2026 UTC | User: “Start B007” | Local Phase 1 refinement prepared. O-11/O-16/O-17 remain Open; remaining O-18 choices remain open. No estimate, owner assignment or approval fabricated. |
