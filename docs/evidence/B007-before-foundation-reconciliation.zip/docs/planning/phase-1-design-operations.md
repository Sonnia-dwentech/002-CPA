# Phase 1 Design, Operations and Review Decisions — B007

**Version:** 0.3 · **Date:** 20 October 2026 UTC  
**Status:** Local planning pack approved by user; detailed decisions and assignment acceptance pending

## Scope and design proposal

Phase 1 is the secure foundation: approved source structure/local setup, API/database/migrations, identity and permissions, responsive navigation, honest current-record dashboard, audit/logging, mocked AI adapter and fail-closed live configuration, reviewed CI/staging/recovery and human acceptance. It is not a working global research lab.

D005 supplies navy navigation, blue accents, light neutral content surfaces, accessible tables/charts and desktop-first responsive direction. UI.png is an illustrative reference only. Do not invent design tokens, assets, metrics, coverage or connected-service states.

| Surface | Phase 1 proposal | Approval still needed |
| --- | --- | --- |
| Sign-in/session/access denied | Delivered only under approved identity/session contract | O-04 plus product-facing states; Justice/product owner |
| Navigation | Clearly distinguish available routes and deferred capabilities | Final labels and whether deferred entries are hidden or visibly unavailable; O-11 |
| Command Centre | Show only approved aggregates from accessible persisted record types | Exact metric catalogue/formulas, filters, permitted record types and date/time semantics; product owner/Justice |
| Search/notifications/geography | No operational control without approved scope and backing data/service | Which entries, if any, appear in foundation; do not imply global coverage or working search |
| Visual assets/accessibility | Reuse approved assets; loading, empty, error, access-denied and unavailable states | Token/asset list, responsive targets and supported accessibility test environment; O-11 |
| Demo data | Wholly synthetic, visibly labelled; no hard-coded live figures | B006 specialist boundaries and fixture review before implementation |

A foundation dashboard must not force Phase 2 idea/research/client modules into Phase 1. If no approved meaningful metric can be supported, record that gap and obtain a scoped product decision before B021/B022. Do not substitute plausible statistics.

## Operational prerequisites and external authority

| Action/decision | Required authority and evidence | Checkpoint / current state |
| --- | --- | --- |
| Repository access, branches, reviews, CI settings | Justice; current B004 evidence and explicit user authority for GitHub activity | B004/B020; blocked/deferred |
| Architecture and identity/tenancy | Justice; product owner for business grants | B005/B013–B016; technical review pending |
| Data/fixtures/source handling | B006 policy plus its deferred specialist reviews | Before affected implementation; local policy approved only |
| Runtime/tooling/local service setup | Justice-approved compatible versions and safe test destinations | Before B010–B012; unset |
| Hosting/database/storage sizing and fees | Justice technical review and CEO/authorised budget owner approval of actual proposal/cost | Before B023/B024; provider/account/ceiling not approved |
| Model/project/credential/budget configuration | Justice and authorised budget owner; separate live-call authority | Before B019 live enablement; live calls not authorised by B007 |
| Staging account access and deployment | Company-controlled accounts, least privilege, reviewed config, explicit provisioning/deployment authority | B024; no resources verified or provisioned |
| Secrets, CORS, redirects and domains | Justice plus authorised operational owner; approved exact environment values | B023/B024; values unset; no credentials in records |
| Backups/retention/recovery | Justice and relevant policy/CEO authority; agreed targets and restore destination | B023/B025; durations/RPO/RTO unset |
| Performance and capacity | Justice/CEO agree workload, test conditions and targets | O-16; before relevant sizing/acceptance; no numeric target invented |
| Support/incident/rollback ownership | CEO and Justice assign accountable people, escalation and authority boundaries | O-17 before staging reliance/release; named owners unset |
| Production | Separate technical/business release evidence and explicit action approval | Outside Phase 1/B007 authorisation |

Unknown cost is not zero or unlimited. No purchase, account creation, credential change, provider call, scheduled automation or outbound message is authorised. These prerequisites identify decisions, not executed actions.

## Proposed review cadence and handoff

Carry forward D006/D010 as a proposal: weekly planning/demo; short daily blocker updates during active work; review per PR when remote workflow is authorised; phase-end technical/business acceptance. The user selected “Carry forward as proposed”, adding “be reminded of no GitHub connection”. This confirms carrying the cadence forward as a proposal, not a scheduled or finally agreed operating timetable. All GitHub connections remain prohibited; PR/merge review is deferred until separately authorised. Meeting days/times, channels, attendees and escalation response times are unset. Nothing is scheduled or sent.

For each selected task, Justice confirms scope/approach and named executor before work. Executor records changes/checks and blocker evidence locally; the reviewer records outcome and revisions; CEO reviews functional scope at phase acceptance. Use progress.md/decisions.md/risks.md as authoritative records. AI may prepare drafts but cannot act as the eligible human reviewer. While GitHub remains deferred, local document review can proceed under explicit user selection; repository implementation/review evidence cannot be fabricated.

## Approval worksheet and Definition of Ready gaps

| Item | Required response / authority | Current evidence |
| --- | --- | --- |
| Phase 1 included/deferred scope | Justice is interim product/scope approver nominated by user; existing CEO gate/release authority unchanged | Scope proposed; no scope sign-off recorded |
| Work-item owners | Justice is interim accountable implementation owner; confirm acceptance and any delegated executors | User nominated Justice; assignment acceptance not recorded |
| Technical approach | Justice records B005 review outcomes/deferrals | Pending |
| Design/navigation/metric decisions | Product owner and Justice resolve O-11 questions above | Pending |
| External prerequisites | Approve or explicitly defer costs/actions with blocking checkpoints | Identified, not approved |
| Review cadence and escalation | Justice/CEO agree operating details | User confirmed carry-forward as proposal; channels/times/agreement unset; GitHub review deferred |
| Estimates/dates/success measures | Justice/CEO after scope/architecture review | Unset; foundation gate evidence is defined, schedule is not |
| Eligible human review and G0 | Resolve B004 and record B008 readiness/sign-offs | Not satisfied; B008 not started |

B007 cannot be marked Done merely because work-item fields are filled. Its completion check requires issues satisfying Definition of Ready, with costs/authority identified and no invented dates/budgets. Missing approvals, assignment acceptance and eligible independent review are real readiness gaps. All B009–B028 remain Not started; none is automatically authorised by reviewing this pack.

Sources: [D005](../../CPA_Development_Handover_Pack_v1/docs/005-ui-ux-design-specification.md), [D006](../../CPA_Development_Handover_Pack_v1/docs/006-development-roadmap-sprint-backlog.md), [D009](../../CPA_Development_Handover_Pack_v1/docs/009-deployment-operations-guide.md), [D010](../../CPA_Development_Handover_Pack_v1/docs/010-developer-working-agreement-and-assistant-instructions.md), [F02](../../feature-spec.md#f02-application-shell-and-command-centre).

## User clarification — 20 October 2026 UTC

User selected cadence option 1 with “be reminded of no GitHub connection”, and answered the implementation-owner/product-approver question with “Keep Justice for the meantime”. Justice is recorded provisionally for both roles in that question. This is a user nomination, not a claim that Justice accepted assignments or approved scope/ADRs. CEO phase/release sign-off remains unchanged. Justice cannot independently review their own authored code. Nothing is scheduled, messaged or connected externally.

## User approval — 20 October 2026 UTC

User: “Approve B007”. Approval of the local planning pack is recorded, covering the refined work-item structure, proposed scope/operational boundaries, interim Justice nomination and proposed cadence. This does not select unanswered design/architecture options, establish Justice's assignment acceptance or technical sign-off, identify an eligible independent reviewer, or authorise spending or GitHub access.

B007 remains In review because its unchanged completion check requires work items satisfying Definition of Ready. Outstanding scope/design and technical decisions must receive explicit outcomes or valid deferrals; the user approval is not represented as proof those readiness gaps are resolved. G0/B008 is a separate execution gate and remains unstarted. No implementation or successor task is authorised.

