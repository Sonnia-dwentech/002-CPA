# CPA Local Foundation API — B011

This is a minimal local FastAPI application, not the completed CPA backend.
It uses the already-installed Python 3.14.8 environment; no packages were installed
or downloaded for B011. See [requirements-local.txt](requirements-local.txt) for
the observed direct/framework versions exercised by the tests. This is not a
complete dependency lock or proof of a clean-machine installation.

## Run locally

In PowerShell:

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B run_local.py
```

The launcher binds only to `127.0.0.1:8000`. Stop it with Ctrl+C.
If that port is occupied, select another local port:

```powershell
python -B run_local.py --port 8001
```

In a second PowerShell terminal:

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/health'
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/openapi.json'
```

These requests use loopback only. They do not connect to GitHub or an external
provider. No service is left running by the test suite.

## Contract

| Request | Result |
| --- | --- |
| `GET /health` | HTTP 200, `{"status":"ok"}`, `Cache-Control: no-store` |
| `GET /openapi.json` | Generated local API schema; no external documentation assets |
| Unknown route | HTTP 404, generic `not_found` error |
| Unsupported method on `/health` | HTTP 405, generic error and `Allow` header |
| Invalid validated request | HTTP 422, generic `validation_error`; no submitted values echoed |
| Unexpected application exception | HTTP 500, generic `internal_error`; no exception text returned |

Error body:

```json
{"error":{"code":"not_found","message":"Resource not found."}}
```

The health check means **process liveness only**. It does not check or claim database,
identity, provider, migration, deployment or overall product readiness. The app has
no business-data routes. Validation and exception behaviour is tested through
test-only routes added to isolated app instances; those routes are not exposed by
the actual application or its OpenAPI schema.

Browser `/docs` and `/redoc` are disabled, so viewing a schema does not require CDN
assets. Debug mode is off. The local launcher disables access logging, proxy-header
trust and the server-version header. It uses critical-only server logging to avoid
printing raw request/exception details. Proper redacted operational logging is
still B017 work; this launcher is not a production logging/deployment design.

The app does not load `.env`, connect to a database, initialise credentials or call
a model. Existing configuration templates remain future configuration guidance,
not active protection mechanisms. No authentication or CORS policy is implemented;
keep this process local and do not expose it through public tunnels or deployment.

## Verify

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B -m unittest discover -s tests -v
```

Tests use Python's standard-library runner, direct ASGI requests and a short-lived
loopback server. No pytest/httpx installation is needed. The startup test chooses
an available local port, starts the actual launcher without a visible child
console, checks the health response and stops the child in a cleanup block.
All inputs and secret canaries are synthetic.

This provides B011 component startup/health/error evidence, not B010's deferred
complete fresh-setup walkthrough. B012 now has a separately authorised disposable PostgreSQL check workflow below. B005's formal technical review and other G0-L deferrals remain
outstanding. See [B011 evidence](../docs/evidence/B011-local-api.md) and
[current progress](../progress.md) for actual acceptance status.


## B012 disposable PostgreSQL migration checks

The user lifted the setup deferral for this local scope on 20 October 2026. Uses installed psycopg 3.3.6 and an existing Docker `postgres:17` image. No downloads or installs are performed. Start the installed Docker Desktop engine first if stopped; this may require local permissions.

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B check_local_database.py
```

The script targets only the local Windows Docker named pipe, inspects the existing image and runs its immutable ID with `--pull=never`. Each invocation creates a uniquely named container, ephemeral loopback port, random password passed through the child environment, and tmpfs storage. The script never selects an existing database/container. Credentials are not saved in source or printed. It stops/removes its test container in cleanup; Docker Desktop itself remains running.

`app/database.py` supplies local connectivity and an atomic batch migration runner with transaction-scoped advisory locking, a history-prefix check and SHA-256 checksums. Ordered SQL files live in `migrations/`. The first migration creates only the empty `cpa` namespace; bookkeeping lives in `cpa_meta.schema_migrations`. Do not edit applied migrations. Add transaction-compatible SQL in a new numbered file; transaction control and nontransactional DDL are outside this runner's supported contract.

The checks demonstrate rollback on constraint failure, recovery by correcting an unapplied migration, preservation of synthetic data after transaction failure, and an explicit test-only rollback to the baseline. They do not prove backup/restore or production disaster recovery. Destructive down-migrations need their own data-loss assessment; there is no automatic general rollback command.

Fixture manifest: `B012-synthetic-probe`, version 1, created by Codex for this task; entirely invented integer pair `(1, 7)` in `cpa.recovery_probe`, temporary test migration 0002. Owner is the B012 executor. Storage is only the generated container's tmpfs; cleanup occurs at the end of each run, with the fixture removed earlier by the tested rollback. Expected outcomes are defined in the script and [B012 evidence](../docs/evidence/B012-local-database.md).

The generated PostgreSQL bootstrap role is privileged solely inside this disposable instance. It is not an approved application runtime role or evidence of least-privilege access. B013/B014 still need user/role/tenancy/session decisions; the API's public health remains liveness-only. No persistent development database or application-wide database readiness is claimed.


## B013 local identity and permission boundary

User approved matrix v0.1 for local continuation on 20 October 2026. `0002_identity_access_references.sql` adds reference metadata for users, client organisations, roles, record scope, grants and case assignments. It creates no accounts or business payloads. Applied migration 0001 is unchanged. The database check runner now discovers all migration files and uses temporary migration 9000 for its recovery fixture.

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B -m unittest discover -s tests -v
python -B check_local_access.py
```

The second command uses the installed offline Docker image and the B012 disposable-database mechanism; Docker named-pipe access may require local permissions. It creates a new `cpa-b013-check-<uuid>` container, runs migrations plus persisted permission checks, and removes the container/tmpfs. No real accounts or persistent store remain. The internal disposable database/user names remain `cpa_b012` for compatibility with the existing local connector; this is never an existing database selection.

`AccessStore.require()` checks current persisted identity, active membership, role/grants, record scope and case assignments. It returns authorised **internal reference metadata**, not a client-safe payload or a business workflow response. A future feature service must construct its approved projection, call this boundary for every access and keep its own content mutations atomic with authorisation. `visible()` returns filtered references; derive visible counts from that result. It is a correctness-first local implementation, not a measured large-dataset query plan.

All feature kinds are disabled by default. Tests explicitly enable synthetic kinds. Neither the normal application nor an environment flag enables a mock login or feature service. `VerifiedIdentity` is a server-only input contract for a future B014 validator; never construct it from request user/role/client fields. Authentication, session verification and endpoint wiring are not implemented by B013.

The evaluator handles the approved record actions, including separate read/edit/export/run/decision permissions and the independent response-author rule. There are no public account, grant or assignment mutation APIs: self-grants, bootstrap, invitations, role changes and account linking cannot be performed through the application. Named bootstrap and approval-backed administration remain prerequisites before real account operation. Policy decisions for future publication, research, exports and client flows do not activate those workflows or waive their later lifecycle gates.

Fixture manifest: `B013-synthetic-access`, version 1, creator/executor Codex; synthetic issuer `synthetic://b013`, nine invented users, two invented client organisations and eight reference records with UUIDs generated from fixed integers in the test script. No names, email addresses, credentials or business content originate from real users. Schema migrations 0001–0002. Expected positive and negative results are in `check_local_access.py`; storage is the new container's tmpfs, cleaned up after each run. Fixture grants are inserted directly by the isolated test harness, not through an unapproved administrator route.

B013 verifies application-layer reference isolation, not PostgreSQL row-level security or a least-privilege database role. The temporary bootstrap role is privileged and must never be used as a deployed application role. Permission checks run anew on every call; in-flight operations and future multi-step mutations need their own transaction/concurrency tests. MFA, session expiry, provider validation and named real-account assignments remain B014/approval work. No claim of complete client-portal or deployment readiness is made.


## B014 approved local session validation

Policy v0.1 is user-approved. Migration 0003 stores opaque-session SHA-256 digests, user references, activity/absolute-expiry timestamps and revocation. Prior migrations remain unchanged. Tokens use 32 random bytes; raw tokens are never saved in the session table. The validator enforces a 30-minute idle timeout and fixed 8-hour absolute lifetime using database UTC time, with equality treated as expired. Activity never renews absolute expiry, and there is no refresh mechanism.

```powershell
Set-Location -LiteralPath 'C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA\backend'
python -B -m unittest discover -s tests -v
python -B check_local_sessions.py
```

The integration command creates a fresh `cpa-b014-check-<uuid>` container from the installed image with pulling disabled, uses loopback only, runs migration/B013/session checks, starts and stops a short-lived HTTP test server, then removes the container/tmpfs. Docker named-pipe access may require local permissions. No credentials are printed and no provider is contacted. Docker Desktop itself remains running.

`app/sessions.py` implements the parser, validator, server-internal issuance helper, session logout and request dependencies. It accepts exactly one well-formed Bearer header; tokens in query strings/cookies and user/role/MFA headers confer no identity or assurance. Logout revokes only the presented session. A database trigger revokes sessions on account disablement, membership removal or identity/scope change, including when the account is restored before the next request.

Future protected routes must use `require_record()` (authentication plus B013 authorisation) or `authenticate()` followed by the appropriate approved policy, and use `require_privileged()` for privileged operations. Privileged operations remain denied because no MFA mechanism is configured. No caller-supplied flag can enable MFA. Database failure is generic 503; invalid credentials are generic 401 with `WWW-Authenticate: Bearer` and no-store. B013 record denial remains 403/404.

Connection stores must be supplied by trusted server wiring through request state, using a request-scoped connection lifecycle. Missing store wiring fails closed. The test harness wires its own database connection and test-only routes. The normal app still exposes only liveness/OpenAPI: no login, session minting, mock-auth toggle, account recovery, logout HTTP route or protected business feature has been enabled. The server-internal issuance helper can only be integrated after a future approved identity verification step. It is not evidence of a human sign-in.

Fixture manifest: `B014-synthetic-sessions`, version 1, Codex executor; reuses B013 synthetic baseline, then adds three invented users (one internal/two clients), three reference records and ephemeral random session tokens under issuer `synthetic://b014`. Schema 0001–0003. Expected outcomes are defined in `check_local_sessions.py` and `tests/test_sessions.py`. Data lives only in the generated tmpfs database; tokens live in test process memory; the whole instance is removed after the run. Test HTTP requests stay on loopback with access logging disabled; never reuse these test credentials in a real environment.

The complete command passes 33 verification groups (9 migration, 10 B013 reference/access, 14 session/HTTP), plus the separate 26-test unit/API suite. No real identity provider, password system, browser sign-in/storage, MFA verification or full sign-in journey has been demonstrated. B016 retains UI work. Request connection pooling, production roles/TLS, operational session-retention cleanup and deployed concurrency/load evidence remain future integration/operations requirements; local expiry is access denial, not a retention policy.


## Localhost status page

Opening `http://127.0.0.1:8000/` now displays a small backend status page with links to health and the API schema. `/health` intentionally remains JSON: `{"status":"ok"}`. The root page confirms that this process responds; it does not check database/provider readiness or provide the B015 frontend. No external assets are loaded. Added after the user's localhost 404 report; 27 unit/API tests passed, including the HTML route and existing security/session checks.
