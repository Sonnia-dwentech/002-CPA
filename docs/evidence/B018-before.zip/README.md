# CPA — Local Working Project

**Organisation:** Dwen Tech Ltd  
**Classification:** Confidential — Internal  
**Project:** Chief Product Architect AI Laboratory

This is the user-selected local CPA project. It currently contains source material, planning documents and local evidence. A minimal local foundation API is present; no complete product or verified remote checkout is established by this folder.

## Start here

1. Read [progress.md](progress.md) for current task status, authorisation and handoff.
2. Read [build-order.md](build-order.md) for task definitions, dependencies and gate boundaries.
3. Consult [decisions.md](decisions.md) and [risks.md](risks.md) before resolving design questions or starting affected work.
4. Use the [documentation index](docs/README.md) for source documents, ADRs, policy and evidence; use [project layout](docs/project-layout.md) to distinguish existing files from proposed future application paths.

Product context is in [blueprint.md](blueprint.md); behaviour and acceptance criteria are in [feature-spec.md](feature-spec.md). Document existence does not establish implementation or technical approval.

## Current working boundary

[G0-L v0.1](docs/planning/G0-local-only-proposal.md) was adopted and [reassessed](docs/evidence/B008-g0-local-reassessment.md) for separately selected local work. All GitHub connections, remote operations, live services, real-client data and deployment remain deferred. Task-specific decisions still apply; no blanket Phase 1 execution authority is implied. Current statuses belong in progress.md.

Preserve the original handover folder, Word documents, archive and UI reference. Original pack instructions describe an earlier proposed remote workflow; the user's current local-only instruction governs this project. Do not interpret original GitHub/Render setup text as authority to connect or provision services.

Justice is the user-nominated interim accountable implementation owner and product/scope approver. Codex may execute selected local tasks; this does not establish Justice's personal acceptance or independent human review. Refer to the ledgers for actual approval evidence.

## Setup and execution

[B010 local setup preparation](docs/local-setup.md) records provisional tooling and deferred fresh-setup verification. [Backend instructions](backend/README.md) cover the loopback API on port 8000; accepted B012–B014 evidence covers disposable local PostgreSQL, access boundaries and synthetic sessions.

**Open the local frontend at http://127.0.0.1:3000/**. [Frontend instructions](frontend/README.md) cover the B015 responsive navigation shell, cache-only dependencies and run/build commands. Features still awaiting implementation are visibly labelled. Real sign-in and application data are not connected; B016 remains unstarted. Fresh isolated setup is reserved for B027 before G1.

Use the [allowed-data and test-fixture policy](docs/policies/allowed-data-and-test-fixtures.md) before future test-data work. Local examples must not be confused with live research or client records.
