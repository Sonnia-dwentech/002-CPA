# CPA Progress Tracker

**Organisation:** Dwen Tech Ltd  
**Product:** Chief Product Architect AI Laboratory  
**Version:** 1.7 draft  
**Last updated:** 20 October 2026 UTC  
**Classification:** Confidential — Internal  
**Current stage:** G0-L accepted; B009 local structure In review; B004 Blocked; B005/B007 In review

This file records task status, evidence, decisions, phase gates and handoffs against [build-order.md](build-order.md). Read [blueprint.md](blueprint.md) for product context and [feature-spec.md](feature-spec.md) for feature behaviour and acceptance criteria. The build order owns task definitions, dependencies and completion checks; this tracker owns recorded progress for this folder.

The user requested `progress.md`, so this is the selected tracker filename rather than the optional `build-progress.md` name mentioned in the build order. B003 establishes the local record workflow below with decisions.md and risks.md. The existing folder remains the working project; remote adoption is deferred.

**Current operating instruction — 20 October 2026:** The user accepted the B001 local inventory and selected `C:\Users\hp.DESKTOP-KVH15G5\Documents\002 CPA` as the working project. All GitHub activity is deferred: do not access, clone, pull, merge or modify the remote repository. Historical remote evidence is retained only as history. This direct instruction governs current work where earlier repository/PR wording differs. The user accepted B002 and B003, then explicitly authorised B005 as a controlled exception limited to work independent of B004. B004 remains Blocked and GitHub activity deferred. The subsequent “Start B006” authorises local policy preparation with B005 review still pending. The user subsequently selected B007 for local refinement. The user subsequently selected B008 for local gate assessment. The user subsequently adopted G0-L v0.1; reassessment passed for limited local scope only. The user subsequently selected B009 for the approved local structure/reference slice. Stop before B010.

## 1. Current snapshot

| Measure | Recorded state |
| --- | --- |
| Build tasks | 105, B001–B105 |
| Done | 5 |
| In review | 3 |
| In progress | 0 |
| Ready | 0 |
| Blocked tasks | 1 — B004 remote verification deferred; original full-G0 assurance still outstanding |
| Not started | 96 |
| Recorded task completion | 5 / 105; task count is not a measure of effort or delivered product value |
| Active build task | B009 In review — local structure and references verified |
| Next candidate | Accept B009 local deliverable; B010 requires separate selection and setup decisions |
| Approved issue / owner / branch | User selected B009 local scope; Codex executed documentation slice; Justice remains nominated accountable owner; remote issue/branch activity deferred |
| Phase approvals | G0-L accepted only; original full-G0 assurance deferred; G1–G6 pending |
| Runtime, CI or acceptance results | No execution evidence recorded |
| Staging / production | Not verified |
| Approved schedule / budget | Not recorded |

**Evidence boundary:** The local planning files exist. Their existence establishes draft documentation, not approved requirements, completed build tasks or a working application. Repository membership, branch protection, PR #2, credentials and deployment statements from the handover pack remain unverified historical context. No external systems were checked at initialisation. During B001, a read-only GitHub metadata query verified the target repository identity, private visibility and default branch; membership/protection/PR checks remain unverified.

## 2. Planning documents and evidence

| Artifact | Local state | Approval / scope note |
| --- | --- | --- |
| [blueprint.md](blueprint.md) | Present; proposed baseline, version 1.2 draft | CEO product approval and Justice technical review pending in the document |
| [feature-spec.md](feature-spec.md) | Draft present, version 0.3; F01–F20 and 65 acceptance criteria | No criterion is claimed passed; B002 reference reconciliation accepted |
| [build-order.md](build-order.md) | Draft present, version 0.8; 105 tasks; adopted G0-L scope recorded | Sequence and gates proposed; all build tasks initially unverified |
| [progress.md](progress.md) | Tracker updated for B009 local review, version 1.7 | Authoritative local status ledger; B003 workflow accepted; remote adoption deferred |
| [Original handover README](CPA_Development_Handover_Pack_v1/README.md) | Present | Source baseline, not completion evidence |
| [Original handover checklist](CPA_Development_Handover_Pack_v1/github/HANDOVER_CHECKLIST.md) | Present | Sign-off still needs actual evidence; no checkboxes inferred complete |

## 3. Status and update rules

| Status | Meaning |
| --- | --- |
| Not started | No task execution is recorded; prerequisites may still be unresolved |
| Ready | Approved issue, owner, scope, dependencies, decisions and test plan are sufficient to begin |
| In progress | The selected authorised task is being executed; record the current scope and evidence |
| Blocked | A specific impediment prevents the task proceeding; record impact, owner/required authority and unblock condition |
| In review | Required implementation/checks are available for the eligible human reviewer; acceptance is still pending |
| Done | Build-order completion checks and applicable independent review/acceptance are evidenced |

Update the task row, phase counts, detailed task record and handoff together. Record the actual UTC date/time when known; do not invent earlier activity dates. Preserve prior decisions, failed checks and superseded evidence through dated entries. If a task is reopened, change its status and record why rather than deleting its earlier history.

Complete only the selected task or authorised batch. Do not automatically start the next task, resolve an open business rule by assumption, call a paid provider or deploy because this tracker names a future action. Relevant tests accompany functional work; later verification tasks do not defer them.

Gate tasks require recorded technical/business sign-off. AI-generated drafts and successful local checks do not replace independent human review or release authority. Keep credentials, private client records and restricted research out of this file.

### 3.1 Authoritative local workflow

- build-order.md owns task definitions/order; progress.md owns current status/blockers; [decisions.md](decisions.md) owns decisions; [risks.md](risks.md) owns risks; docs/evidence holds task reports. Product documents are not alternative status ledgers.
- B001–B105 are local work-item IDs. Each register row maps by the identical ID/title to its build-order definition and links its report. No GitHub issue numbers or URLs are invented. For selected local documentation, the user's instruction is the authorisation reference; remote issue creation remains deferred.
- Before work, record scope, executor, dependencies/gates, decisions, risks and planned checks. Ready requires adequate approved scope and prerequisites. Selection alone does not bypass blockers.
- During work, record In progress or a specific Blocked condition with evidence, authority and unblock action. Preserve prior source files, failed checks and acceptance history.
- At review, update the task row, phase counts, report, relevant decision/risk changes and handoff together. In review means checks complete and human acceptance pending; Done needs applicable acceptance evidence. Document acceptance does not approve architecture or gates.
- Stop after the selected task. Reopen with dated reasons if needed. Cadence, named assignments and schedule commitments remain O-18/B007 decisions.

## 4. Phase summary

| Stage | Tasks | Total | Done | Not started | Exit |
| --- | --- | ---: | ---: | ---: | --- |
| Preparation | B001–B008 | 8 | 5 | 0 | G0-L accepted only; B004 Blocked, B005/B007 In review |
| Phase 1 Foundation | B009–B028 | 20 | 0 | 19 | B009 In review; G1 pending |
| Phase 2 Idea Studio MVP | B029–B056 | 28 | 0 | 28 | G2 pending |
| Phase 3 Portfolio / stress testing | B057–B066 | 10 | 0 | 10 | G3 pending |
| Phase 4 Voice / Discovery | B067–B081 | 15 | 0 | 15 | G4 pending |
| Phase 5 Advanced research / modelling | B082–B099 | 18 | 0 | 18 | G5 pending |
| Release lane | B100–B105 | 6 | 0 | 6 | G6 pending; deployment unverified |
| **Total** | **B001–B105** | **105** | **5** | **96** | **1 Blocked, 3 In review; G0-L only accepted** |

G2 is the MVP completion point. The release lane may follow an accepted G2, G3, G4 or G5 scope, as described in the build order; deferred later features need not be built before an approved MVP release. Each release needs its own version, evidence and sign-off. G6 approval does not by itself prove that B105 deployment succeeded.

## 5. Build task register

Task titles are copied from the current build order for navigation. Consult that file for full scope, traceability and completion checks. Owners, issue links, PRs and evidence are unassigned/unrecorded for every row unless a detailed entry below says otherwise. No row is marked Ready solely because it appears next numerically.

### Preparation and baseline

| Task | Deliverable | Status | Evidence / issue |
| --- | --- | --- | --- |
| B001 | Inventory current planning files and verified target repository; record source differences, versions and baseline status | Done | [B001 inventory](docs/evidence/B001-baseline-inventory.md); user acceptance on 20 October 2026; local-only scope |
| B002 | Obtain/record product and technical decisions on baseline conflicts; align approved requirement references | Done | [B002 reconciliation](docs/evidence/B002-baseline-reconciliation.md); user acceptance 20 October 2026 |
| B003 | Establish authoritative progress, decision and risk records with task/issue links | Done | [B003 records setup](docs/evidence/B003-records-setup.md); user acceptance 20 October 2026 |
| B004 | Verify CPA repository, memberships, MFA, protected branches, reviewer eligibility and actual PR #2 outcome | Blocked | [B004 local preflight](docs/evidence/B004-local-preflight.md); GitHub verification deferred |
| B005 | Review core architecture ADRs: frontend/API/database, identity/roles/tenancy, environments and service boundaries | In review | [Local ADR review](docs/evidence/B005-local-architecture-review.md); user accepted; Justice review outcome pending |
| B006 | Define initial privacy, secrets, source/IP and client-isolation boundaries for foundation/MVP | Done | [B006 policy report](docs/evidence/B006-policy-review.md); user-approved limited local scope; specialist reviews deferred |
| B007 | Refine and approve Phase 1 issues, design scope, operational prerequisites and review cadence | In review | [B007 refinement](docs/evidence/B007-phase-1-refinement.md); local pack user-approved; Definition of Ready evidence pending |
| B008 | **G0-L: Record limited local readiness acceptance** | Done | [G0-L reassessment](docs/evidence/B008-g0-local-reassessment.md); user-approved limited scope only |

### Phase 1 Foundation

| Task | Deliverable | Status | Evidence / issue |
| --- | --- | --- | --- |
| B009 | Prepare approved repository structure and import handover/ADR references at valid paths | In review | [Local structure/reference report](docs/evidence/B009-local-structure.md); approved G0-L slice only |
| B010 | Document and verify Windows-compatible local setup and configuration template | Not started | Not recorded |
| B011 | Add FastAPI startup, health contract and initial OpenAPI/error structure | Not started | Not recorded |
| B012 | Add PostgreSQL connectivity and versioned migration workflow | Not started | Not recorded |
| B013 | Implement identity/user references and the approved role/record authorisation boundary | Not started | Not recorded |
| B014 | Implement approved authentication/session validation in the backend | Not started | Not recorded |
| B015 | Build responsive Next.js navigation shell with accurate feature availability | Not started | Not recorded |
| B016 | Connect sign-in/session and access-denied UI to backend permissions | Not started | Not recorded |
| B017 | Implement initial audit events and redacted operational request logging | Not started | Not recorded |
| B018 | Define AI adapter interface, output/error contracts and mock provider tests | Not started | Not recorded |
| B019 | Implement baseline configuration/usage hooks and fail-closed live-AI enablement | Not started | Not recorded |
| B020 | Add CI lint/test, dependency and available secret-scanning checks | Not started | Not recorded |
| B021 | Implement approved current-record dashboard queries and filter contracts | Not started | Not recorded |
| B022 | Connect dashboard cards/lists with loading, empty and error states | Not started | Not recorded |
| B023 | Prepare reviewed staging service/configuration manifests and deployment instructions | Not started | Not recorded |
| B024 | Provision authorised staging resources and deploy the reviewed foundation | Not started | Not recorded |
| B025 | Establish foundation backups, restoration procedure and migration rollback assessment | Not started | Not recorded |
| B026 | Verify staging UI/API/DB, direct-record denial and secure configuration | Not started | Not recorded |
| B027 | Verify accessible shell/dashboard, operational logs and local setup handover | Not started | Not recorded |
| B028 | **G1: Demonstrate and accept the foundation** | Not started | Not recorded |

### Phase 2 Idea Studio MVP

| Task | Deliverable | Status | Evidence / issue |
| --- | --- | --- | --- |
| B029 | Resolve Phase 2 workflow, field validation, source strategy, queue, model/budget, scoring and export decisions; approve issues | Not started | Not recorded |
| B030 | Add idea schema/migration and ownership constraints | Not started | Not recorded |
| B031 | Implement idea create/read/edit/archive API with action-specific validation | Not started | Not recorded |
| B032 | Build idea list/editor and persisted draft workflow | Not started | Not recorded |
| B033 | Add source/evidence schema and permitted MVP ingestion/parser | Not started | Not recorded |
| B034 | Add evidence inspector and hypothesis/no-source presentation | Not started | Not recorded |
| B035 | Implement research-run persistence, approved state contract and idempotent job creation | Not started | Not recorded |
| B036 | Implement worker execution, timeout, bounded retry, cancellation and restart recovery | Not started | Not recorded |
| B037 | Implement per-run/user budget enforcement and AI usage metering for the analysis path | Not started | Not recorded |
| B038 | Implement versioned prompt/schema orchestration and structured assessment validation using mocks | Not started | Not recorded |
| B039 | Execute narrowly authorised live-adapter verification in staging, when approved | Not started | Not recorded |
| B040 | Connect Analyse/progress/result UI to persisted runs and structured output | Not started | Not recorded |
| B041 | Implement score calculation, validation and scoring-version/risk representation | Not started | Not recorded |
| B042 | Add scoring rationale, uncertainty, risk and missing-evidence UI | Not started | Not recorded |
| B043 | Add dossier version schema and saved-version API | Not started | Not recorded |
| B044 | Implement Challenge assumptions orchestration and relationship to its source assessment | Not started | Not recorded |
| B045 | Add challenge/revise/save-version interface | Not started | Not recorded |
| B046 | Implement review submission, approved transitions and authorised human decisions | Not started | Not recorded |
| B047 | Build review queue and approve/return/reject interface | Not started | Not recorded |
| B048 | Implement export generation and private file retrieval for a selected dossier version | Not started | Not recorded |
| B049 | Add export status/download interface and version identification | Not started | Not recorded |
| B050 | Implement permission-filtered basic Knowledge Hub/dossier-source retrieval | Not started | Not recorded |
| B051 | Extend audit, permitted usage/settings and approved review notifications | Not started | Not recorded |
| B052 | Extend Command Centre with real idea/run/review/spend data | Not started | Not recorded |
| B053 | Run complete MVP end-to-end and score/evidence/export regression suite | Not started | Not recorded |
| B054 | Verify MVP record isolation, injection/refusal handling and recoverable failures in staging | Not started | Not recorded |
| B055 | Complete MVP accessibility/usability review and technical handover | Not started | Not recorded |
| B056 | **G2: Demonstrate and accept the Idea Studio MVP** | Not started | Not recorded |

### Phase 3 Portfolio and stress testing

| Task | Deliverable | Status | Evidence / issue |
| --- | --- | --- | --- |
| B057 | Approve product schema/stages, recommendation vocabulary and scenario/review rules | Not started | Not recorded |
| B058 | Implement product registry schema/API and idea/evidence relationships | Not started | Not recorded |
| B059 | Build portfolio list/detail/editor and review-history display | Not started | Not recorded |
| B060 | Implement product review request and assessment persistence | Not started | Not recorded |
| B061 | Implement optimistic/base/pessimistic scenarios with approved inputs/formulas | Not started | Not recorded |
| B062 | Add product-specific critical challenge and evidence/counterargument output | Not started | Not recorded |
| B063 | Implement recommendation decisions and portfolio review history | Not started | Not recorded |
| B064 | Build stress-test results, scenarios and decision panels; extend portfolio/dashboard links | Not started | Not recorded |
| B065 | Run product-specific, permissions, failure and accessibility verification | Not started | Not recorded |
| B066 | **G3: Demonstrate and accept portfolio intelligence** | Not started | Not recorded |

### Phase 4 Voice and Discovery

| Task | Deliverable | Status | Evidence / issue |
| --- | --- | --- | --- |
| B067 | Approve Phase 4 issues, consent/retention, voice transport and secured website/outbound contracts | Not started | Not recorded |
| B068 | Implement consent, session/transcript schema and retention/access controls | Not started | Not recorded |
| B069 | Implement approved voice provider transport with permissioned backend integration | Not started | Not recorded |
| B070 | Build microphone/session UI and streaming transcript with honest availability states | Not started | Not recorded |
| B071 | Implement permission-filtered knowledge/project context in voice | Not started | Not recorded |
| B072 | Implement session summary/actions, project linkage and saved-session retrieval | Not started | Not recorded |
| B073 | Implement Discovery client/enquiry/consent/reference schema and secured intake validation | Not started | Not recorded |
| B074 | Connect approved website intake and verify receipt/failure semantics | Not started | Not recorded |
| B075 | Implement client-isolated enquiry retrieval and internal queue API | Not started | Not recorded |
| B076 | Build restricted enquiry queue/detail/triage interface | Not started | Not recorded |
| B077 | Implement missing-information questions and solution proposal drafts with evidence/IP labels | Not started | Not recorded |
| B078 | Implement version-specific human outbound approval and approved channel integration | Not started | Not recorded |
| B079 | Extend permitted knowledge, notifications and dashboard links for delivered Phase 4 records | Not started | Not recorded |
| B080 | Verify voice/Discovery security, consent, failure recovery, usability and access | Not started | Not recorded |
| B081 | **G4: Demonstrate and accept Voice and Discovery** | Not started | Not recorded |

### Phase 5 Advanced research and modelling

| Task | Deliverable | Status | Evidence / issue |
| --- | --- | --- | --- |
| B082 | Approve Phase 5 issues, geography/schedule/source rights, modelling formulas and advanced evaluation | Not started | Not recorded |
| B083 | Implement geography catalogue and explicit region membership | Not started | Not recorded |
| B084 | Build scope/sector/window/source/budget selectors | Not started | Not recorded |
| B085 | Implement approved scan source collection/deduplication and actual coverage logs | Not started | Not recorded |
| B086 | Implement scan opportunity extraction and human-review candidate persistence | Not started | Not recorded |
| B087 | Build results/evidence drill-down and candidate-to-idea promotion | Not started | Not recorded |
| B088 | Implement coverage display and any separately approved heatmap | Not started | Not recorded |
| B089 | Implement authorised schedules, recurrence ownership and pause/cancel | Not started | Not recorded |
| B090 | Implement scheduled opportunity alerts with confidentiality/preferences | Not started | Not recorded |
| B091 | Implement approved academic connector with rights/provenance persistence | Not started | Not recorded |
| B092 | Build academic findings/uncertainty and potential-application review | Not started | Not recorded |
| B093 | Implement commercial assumptions/model schema and deterministic calculation engine | Not started | Not recorded |
| B094 | Build editable business model/scenario interface | Not started | Not recorded |
| B095 | Implement editable business-plan, investment-memo and pitch-outline generation | Not started | Not recorded |
| B096 | Extend Knowledge Hub/search to approved academic, scan and modelling records | Not started | Not recorded |
| B097 | Implement agreed advanced groundedness/citation/contradiction/cost evaluation and guardrails | Not started | Not recorded |
| B098 | Verify advanced end-to-end, coverage, source licensing, recovery and accessible UI | Not started | Not recorded |
| B099 | **G5: Demonstrate and accept advanced capabilities** | Not started | Not recorded |

### Release lane

| Task | Deliverable | Status | Evidence / issue |
| --- | --- | --- | --- |
| B100 | Define candidate version, included/deferred features, defect register and production success/recovery targets | Not started | Not recorded |
| B101 | Complete release security/privacy/access review and staging regression | Not started | Not recorded |
| B102 | Demonstrate production backup/restore readiness, migration plan and rollback assessment | Not started | Not recorded |
| B103 | Finalise production configuration, monitoring/alerts, runbooks, access and support handover | Not started | Not recorded |
| B104 | **G6: Obtain release-specific technical and CEO approval** | Not started | Not recorded |
| B105 | Deploy approved release, perform scoped production smoke checks and record handoff | Not started | Not recorded |

## 6. Gate and approval register

| Gate | Task | Required acceptance | Status | Evidence / date |
| --- | --- | --- | --- | --- |
| G0-L Local-only entry | B008 | Adopted local scope, slice readiness, review limitations and preservation | Accepted for local scope only | [Reassessment](docs/evidence/B008-g0-local-reassessment.md); original full-G0 conditions deferred |
| G1 Foundation | B028 | Secure signed-in staging application, API/DB, checks, logs and real-record dashboard | Pending | Not recorded |
| G2 MVP | B056 | Full idea-to-reviewed-dossier journey with retrieval/export and failure/access evidence | Pending | Not recorded |
| G3 Portfolio | B066 | Product assessment, scenarios, critical challenge and human decision history | Pending | Not recorded |
| G4 Voice / Discovery | B081 | Saved permissioned voice session and secure human-reviewed client workflow | Pending | Not recorded |
| G5 Advanced capabilities | B099 | Rights-aware scoped/scheduled research, academic analysis and editable modelling | Pending | Not recorded |
| G6 Production launch | B104 | Release-specific technical acceptance and CEO production approval | Pending | Not recorded |

CEO product/business approval, Justice technical acceptance and eligible independent PR review must be evidenced in their relevant contexts. No signature, reviewer identity, GitHub link or approval date is fabricated here.

## 7. Open prerequisites and decision register

### 7.1 Source reconciliation

B001’s findings are preserved in its accepted report. B002 dispositions are recorded in [the reconciliation report](docs/evidence/B002-baseline-reconciliation.md); broader implementation decisions remain gated.

| Reference | Disposition | Remaining action / authority | Status |
| --- | --- | --- | --- |
| R01 Schedule | Chart marked illustrative, not approved | Justice/CEO estimate after architecture review, O-18 | Documentation corrected; estimates open |
| R02 Decision IDs | O-01–O-18 restored/aligned across current documents | Underlying authorities/decisions in B002 report | References aligned |
| R03 Team | User: human developer with AI assistance | Justice assigns actual person/access later | User decision recorded |
| R04 Source paths | Actual local pack paths indexed; originals preserved | B009 local reference slice; remote alignment deferred | Local references verified |
| R05 Recommendations | User: Continue, Improve, Pivot, Pause, Stop | Product owner/Justice define scenario semantics at B057 | User decision recorded |
| R06 Proposed design | Explicitly subject to ADRs | Justice at B005 and relevant later tasks | Deferred with dependencies |
| R07 Status arrows | Unordered idea statuses; dossier versions separate | Product owner/Justice approve transitions at B029 | Documentation corrected; rules open |
| R08 Tracker filename | progress.md selected by user | B003 local process formalisation | Naming aligned |

### 7.2 Decision tracking labels

O-label meanings now align with blueprint Section 20 and feature-spec Section 10. The B002 report names responsible roles and dependent tasks. This mapping is not an approved ADR or personal assignment; only the explicit user choices below are resolved.

Current states, authorities, checkpoints and evidence: [decisions.md](decisions.md#current-decisions). Potential risks: [risks.md](risks.md). The B003 pre-edit snapshot preserves the prior table.

### 7.3 Blockers and defects

B002 and B003 are accepted and Done. Decisions and risks retain required authorities and affected tasks in their canonical registers. B004 remains remote-deferred; implementation defects are unassessed.

B001 has no remaining completion blocker; the user accepted the local inventory on 20 October 2026. The initial sandbox proxy failure was resolved through approved read-only escalation. Implementation defects remain unassessed. The user selected this existing folder as the working project; another checkout is not required for B001. All GitHub activity is deferred. Open prerequisites above must be resolved before dependent tasks become Ready. Future blocker entries should identify task, impact, required authority/owner, evidence, unblock condition and resolution date.

**B004 blocker:** Current remote governance evidence cannot be obtained under the user's GitHub deferral. User authority clarification is needed; Justice owns verification/replanning. See [preflight and exact gaps](docs/evidence/B004-local-preflight.md). The user subsequently authorised the narrow B005 exception in build-order.md; the B004 blocker remains unchanged.

## 8. Verification and release evidence

| Area | Current evidence state |
| --- | --- |
| Document structure | Initial tracker generated from 105 build-order task rows; task identity/status/count checks described in the initial activity entry |
| AT-01–AT-10 | Not run; original acceptance scenarios remain in the feature spec/build order |
| AC-F01 through AC-F20 criteria | Not run; no criterion claimed passed |
| Unit / integration / end-to-end tests | No runtime test results recorded |
| Security / record and client isolation | Not verified |
| Accessibility / usability | Not verified |
| Provider mocks | No execution results recorded |
| Live model / source / voice / website integrations | Not verified; no live provider action authorised by this file |
| CI / independent PR review | Not recorded |
| Backups / restoration / migrations / rollback | Not verified |
| Staging deployment / smoke checks | Not verified |
| Production release / approval / smoke checks | Not recorded / not verified |

For future releases, record release version/commit, included and deferred features, required gate, checks/defects, migration and restore evidence, rollback owner/criteria, Justice acceptance, CEO approval, deployment outcome and production verification. Separate each release record; repeating B100–B105 requires new evidence rather than reusing an earlier sign-off.

## 9. Detailed task evidence template

B001 evidence is recorded below and in the linked inventory. Copy this template for subsequent selected tasks; placeholders are not evidence.

```text
Task ID and title:
Linked approved issue:
Status:
Owner / authorised scope:
Start / last update / completion time in UTC:
Dependencies and gate evidence:
Decision / ADR references:
Repository / branch / commit / PR:
Changes and relevant files:
Checks run, exact commands and actual outcomes:
Acceptance criteria verified and evidence links:
Mocked versus live-provider evidence:
Migration / backup / restore / rollback evidence, if applicable:
Independent reviewer and review outcome:
Technical / business acceptance, if required:
Defects / blockers / unresolved risks:
Next eligible task and handoff:
```

### B001 execution record

Historical check counts and next-step notes describe the B001 handoff; current register status takes precedence.

- **Scope/authority:** User explicitly instructed “Start B001”; inventory and read-only target-repository identity check only.
- **Status:** Done. Executor: Codex; accepted by the user on 20 October 2026 through the explicit instruction quoted in the report. No code-review/phase approval is implied.
- **Evidence:** [B001 baseline inventory](docs/evidence/B001-baseline-inventory.md), including 22 source paths/versions/hashes, 14 matching ZIP files, command outcomes and eight interpretation/path findings.
- **Working project:** Existing local folder selected by the user. Earlier remote identity/private visibility/main observations are historical; all GitHub activity, including B004 remote checks, is deferred.
- **Changes:** Added inventory report; updated this tracker. Source requirements and B002 decisions unchanged.
- **Verification:** PASS — 105 task identities; B001 In review and 104 Not started; 22 baseline records; all 21 input hashes other than the intentionally updated progress.md unchanged; local links valid; 65 feature acceptance criteria confirmed. No runtime test or deployment claim.
- **Acceptance:** Explicit user acceptance recorded for B001 local inventory only; all gates remain pending. Identified conflicts remain for B002.
- **Next:** B002 requires a separate explicit selection and remains Not started. B003 remains Not started.

### B002 execution record

- **Authority:** User instruction “Start B002”; existing local-only/GitHub-deferred instruction retained.
- **Status:** Done. User: “I have accepted B002”, 20 October 2026 UTC.
- **User decisions:** “Human developer with AI assistance”; “Yes, include all” for Continue, Improve, Pivot, Pause and Stop.
- **Evidence:** [B002 reconciliation](docs/evidence/B002-baseline-reconciliation.md), [pre-edit snapshot](docs/evidence/B002-before.zip), [input hashes](docs/evidence/B002-input-hashes.json).
- **Changes:** Blueprint 1.1, feature spec 0.2, build order 0.2 and tracker 0.4. Original handover assets and accepted B001 report preserved.
- **Remaining decisions:** Responsible roles and dependent tasks recorded for O-01–O-18. No Justice technical/phase signature invented.
- **Verification:** PASS — pre-edit archive matches original hashes; original sources and B001 report unchanged; all 105 task definitions preserved; 1 Done / 1 In review / 103 Not started; 18 decision rows aligned; 65 acceptance criteria retained; local links and Markdown fences valid. No runtime or deployment claims.
- **Boundary at initial review:** B003 had not started. Subsequently selected by user; GitHub still deferred.

### B003 execution record

- **Authority:** User “Start B003”; dependency B002 accepted by “I have accepted B002”. Executor: Codex. Date: 20 October 2026 UTC; exact times not recorded.
- **Status:** Done; user accepted the local record structure and maintenance workflow on 20 October 2026 UTC.
- **Scope:** Linked progress, decision and risk records; preserve existing work. No application, remote or B004 work.
- **Evidence:** [B003 report](docs/evidence/B003-records-setup.md), [snapshot](docs/evidence/B003-before.zip), [input hashes](docs/evidence/B003-input-hashes.json).
- **Limits:** Documentation checks only; no runtime or gate approval. O-18 broader choices remain open.

### B004 execution record

- **Authority/date:** User “Start B004”; 20 October 2026 UTC. B003 prerequisite Done. Executor: Codex.
- **Scope:** Local preflight only; current GitHub prohibition retained. No remote action or successor work.
- **Status:** Blocked. User must clarify read-only access authority or retain deferral and arrange approved replanning with Justice.
- **Evidence:** [B004 preflight](docs/evidence/B004-local-preflight.md) and [register snapshot](docs/evidence/B004-before.zip). Local .git marker absent; remote controls and PR outcome unverified.
- **Checks:** 105 task rows; 3 Done, 1 Blocked, 101 Not started; original sources, build definitions and prior evidence preserved.

### B005 execution record

- **Authority:** User explicitly selected B005 as a controlled exception, limited to work independent of blocked B004. Date: 20 October 2026 UTC. Executor: Codex; technical decision owner: Justice.
- **Scope/status:** In review for the local independent scope. Four proposed ADRs cover stack, identity/roles/tenancy, environments and service boundaries. Full task acceptance is pending Justice's decisions; O-03/O-04 remain Open.
- **Evidence:** [B005 report](docs/evidence/B005-local-architecture-review.md), [ADR index](docs/adr/README.md), [pre-edit snapshot](docs/evidence/B005-before.zip), [input hashes](docs/evidence/B005-input-hashes.json).
- **Limits:** No actual repository alignment, account/MFA/branch/reviewer/PR checks, implementation, provider selection, provisioning or live calls. B004 remains Blocked; no B006 work or gate approval.

### B006 execution record

- **Authority/date:** User “Start B006”, 20 October 2026 UTC; local drafting only. Executor: Codex. B004/B005 completion is not inferred.
- **Status:** Done for user-approved limited local scope. [Policy](docs/policies/allowed-data-and-test-fixtures.md) covers permitted/restricted data, synthetic fixtures, secrets, source/IP, privacy and client boundaries.
- **Evidence:** [B006 report](docs/evidence/B006-policy-review.md), [snapshot](docs/evidence/B006-before.zip), [input hashes](docs/evidence/B006-input-hashes.json).
- **Remaining:** Justice and designated policy/source authorities must record approval. O-04 implementation decisions, O-06/O-12 details and all gates remain open as applicable.
- **Boundary:** No live-data use, implementation, external access or B007 start.

### B007 execution record

- **Authority/date:** User “Start B007”, 20 October 2026 UTC. Executor: Codex; local documentation only.
- **Status:** In review. [20 Phase 1 work-item cards](docs/planning/phase-1-work-items.md) and [design/operations worksheet](docs/planning/phase-1-design-operations.md) prepared; Definition of Ready not yet satisfied.
- **Evidence:** [B007 report](docs/evidence/B007-phase-1-refinement.md), [snapshot](docs/evidence/B007-before.zip), [input hashes](docs/evidence/B007-input-hashes.json).
- **Remaining:** Justice’s acceptance of the interim owner nomination, scope/design choices, relevant architecture decisions, operational authority and agreed cadence details. Estimates/dates unset. No fabricated sign-off.
- **Boundary:** B004/B005 unchanged; B008 and all Phase 1 implementation tasks remain Not started. No remote action or provisioning.

### B008 execution record — original full-G0 assessment (historical)

- **Authority/date:** User “Start B008”, 20 October 2026 UTC. Codex assessed local evidence only.
- **Status/outcome:** Blocked; G0 Hold, not accepted. No technical/CEO signature inferred from prior local document approvals.
- **Evidence:** [Gate assessment and closure requirements](docs/evidence/B008-g0-readiness-assessment.md), [snapshot](docs/evidence/B008-before.zip), [input hashes](docs/evidence/B008-input-hashes.json).
- **Blockers:** B004 access/review evidence; B005 technical review; B007 planning readiness; eligible independent reviewer; CEO scope/Justice readiness confirmations.
- **Boundary:** No external access or implementation; B009 remains Not started. Assessment completion does not mean gate completion.

### B008 G0-L adoption and reassessment

- **Authority:** User explicitly approved G0-L v0.1 and B009 local structure/reference scope, retained restrictions/deferrals and instructed no B009 start.
- **Outcome:** B008 Done for G0-L only. The [reassessment](docs/evidence/B008-g0-local-reassessment.md) records evidence against each local criterion; original full-G0 controls/sign-offs are not claimed satisfied.
- **Owners:** Justice's existing interim nomination retained; no new personal acceptance inferred. Executor for later B009 is recorded at selection.
- **Boundary:** B004 Blocked; B005/B007 In review; B009–B105 Not started. No technical/provider/business decision or remote/deployment approval inferred.

### B009 local execution record

- **Authority/date:** User “Start B009”, 20 October 2026 UTC; G0-L and local B009 scope already accepted. Justice remains nominated accountable owner; Codex executed this local slice.
- **Status:** In review; local documentation acceptance pending.
- **Changes:** Root README, docs index, actual/proposed layout guide and evidence report; progress update only among existing files.
- **Evidence:** [B009 report](docs/evidence/B009-local-structure.md), [input hashes](docs/evidence/B009-input-hashes.json), [progress snapshot](docs/evidence/B009-before.zip).
- **Boundary:** No remote import/compatibility claim, application code, install, Git initialisation or provider activity. B010 remains Not started.

## 10. Activity log

### 20 October 2026 UTC — Initial tracker draft

- Request: draft `progress.md` for the existing CPA planning documents.
- Read the current build order and local file inventory; initialise all 105 task rows as Not started with no issue/evidence references.
- Carry forward the build order's source discrepancies and pending decisions for review; do not resolve them by assumption.
- Record planning-document drafting separately from implementation completion. No build task, gate, test, external access check or deployment is claimed complete.
- Document checks: generation verified the ordered B001–B105 input sequence. Final consistency checks cover unique task IDs, copied titles, initial statuses, phase totals, gate/task references and local links.
- Scope of change: create this tracker only. No blueprint, feature specification, build-order definition, source document or application file is modified.

### 20 October 2026 UTC — B001 inventory executed

- Verified 22 pre-existing local files and their hashes; confirmed all 14 ZIP entries match extracted sources.
- Confirmed target repository via read-only GitHub metadata after a sandbox proxy failure and successful approved escalation.
- Recorded the working folder's non-Git status and source conflicts; no source requirements reconciled.
- Set B001 to In review, with 104 tasks Not started and 0 Done; human acceptance has not been recorded.
- Added the B001 report and updated this ledger only. Stopped before B002.

### 20 October 2026 UTC — B001 accepted for local continuation

- User explicitly accepted the B001 local baseline inventory and instructed that it be marked Done.
- Selected the existing folder as the working project and deferred all GitHub activity, including access, clone, pull, merge and remote modification.
- Updated only the B001 report and this tracker; preserved the inventory hashes, earlier execution history and source material.
- Carried identified conflicts forward to B002 without resolving them. B002 remains Not started by explicit instruction.
- Current totals: 1 Done, 0 In review, 104 Not started; all phase/release gates pending.

### 20 October 2026 UTC — B002 reconciliation prepared

- User selected B002, then confirmed human developer with AI assistance and all five recommendation labels.
- Preserved pre-edit planning files; corrected references, schedule qualification, actual source paths, unordered statuses and local workflow wording.
- Recorded remaining decision authorities and dependent-task blocks; kept original source files and B001 history intact.
- B002 In review; totals 1 Done, 1 In review, 103 Not started. B003 not started; all gates pending.

### 20 October 2026 UTC — B002 accepted; B003 prepared

- Recorded user acceptance of B002 and marked Done; preserved review history.
- Continued selected B003: linked canonical records, local work-item mapping and maintenance rules.
- B003 In review; 2 Done, 1 In review, 102 Not started. All gates pending.

### 20 October 2026 UTC — B003 accepted

- User: “I accept the B003 local record structure and maintenance workflow.”
- Marked B003 Done; local record structure/workflow accepted. Open decisions, risk controls and all phase gates retain their separate approval requirements.
- Totals: 3 Done, 0 In review, 102 Not started. B004 remains unstarted; all GitHub activity deferred.
- Verified all 105 task rows and totals; preserved prior review-stage verification and activity history.

### 20 October 2026 UTC — B004 local preflight

- User selected B004. Reviewed local requirements and historical evidence without accessing GitHub.
- Recorded six verification gaps and the authority blocker; no control marked verified or unprovisioned without evidence.
- Totals: 3 Done, 1 Blocked, 101 Not started. No gate accepted; B005 not started.

### 20 October 2026 UTC — B005 controlled local exception

- User explicitly authorised B005 work independent of B004. Recorded the exception without changing task definitions, B004 status or gates.
- Prepared four proposed ADRs with options, trade-offs, decision authorities and explicit deferred inputs. No provider or business grant selected by assumption.
- B005 In review for the local independent scope; totals 3 Done, 1 Blocked, 1 In review, 100 Not started. Justice's decisions and product-owner access choices remain outstanding.

### 20 October 2026 UTC — B005 user acceptance recorded

- User stated: “I accept B005”. Recorded acceptance of the local review deliverable under the controlled exception.
- This statement does not identify the user as Justice or record Justice's substantive ADR review. No technical sign-off or waiver of the named completion requirement is inferred.
- B005 remains In review pending that review outcome. Pending choices may be explicitly deferred with rationale, owner and checkpoint; not every implementation choice must be settled to accept the review.
- B004 remains Blocked; B006 not started; task totals unchanged.

### 20 October 2026 UTC — B006 local policy prepared

- User selected B006 after accepting the B005 local review deliverable. Recorded the later local preparation authority without clearing B004/B005 or claiming Justice approval.
- Drafted allowed-data/test-fixture policy and review checklist. Sensitive/live client data remains prohibited pending required reviews.
- Totals: 3 Done, 1 Blocked, 2 In review, 99 Not started. No gate accepted; B007 not started.

### 20 October 2026 UTC — B006 scoped policy approved

- User: “Approve B006”. Marked B006 Done for the limited local policy-definition scope described in the preceding acceptance clarification.
- Recorded user approval without attributing specialist sign-offs. Justice technical review and designated policy/source reviews remain explicit downstream prerequisites in policy version 0.2.
- Totals: 4 Done, 1 Blocked, 1 In review, 99 Not started. B004/B005 unchanged; all gates pending; B007 not started.

### 20 October 2026 UTC — B007 local refinement prepared

- User selected B007. Prepared 20 local work-item cards with value, scope, non-goals, unchanged acceptance checks, dependencies, test/security plans, owner gaps and design references.
- Added Phase 1 design/operations/cadence proposal and approval worksheet. Asked user about cadence and named assignments; unanswered choices remain pending.
- Totals: 4 Done, 1 Blocked, 2 In review, 98 Not started. No work item declared Ready; no gate approved.

### 20 October 2026 UTC — B007 user clarifications

- User confirmed cadence option 1 as a proposal and reiterated no GitHub connection.
- User nominated Justice “for the meantime” for Phase 1 implementation ownership and product/scope approval. Recorded the interim roles without inferring acceptance or technical/scope sign-off.
- If Justice authors work, independent human review needs another eligible reviewer. CEO gate/release authority retained.
- Statuses unchanged; no meetings, messages, external connections or B008 work.

### 20 October 2026 UTC — B007 local pack user-approved

- User: “Approve B007”. Recorded approval of the local planning pack, preserving unselected decisions and outstanding authority/readiness evidence.
- B007 remains In review: work-item Definition of Ready is not yet evidenced. No Justice technical review, assignment acceptance, budget or G0 approval inferred.
- Status totals unchanged; no GitHub activity, scheduling, messages or successor work.

### 20 October 2026 UTC — B008 G0 assessed locally

- User selected B008. Reviewed baseline/ADR/policy/work-item evidence and original gate requirements.
- Recorded Hold with five explicit closure actions. Prior approvals retained; no prerequisite status silently upgraded.
- Totals: 4 Done, 2 Blocked, 2 In review, 97 Not started. G0 not accepted; B009–B105 Not started.

### 20 October 2026 UTC — G0-L adopted and accepted

- User approved revised local gate and proposed first local scope while retaining restrictions/deferred reviews.
- Reassessment passed G0-L; B008 marked Done only for local entry. Original full-G0 assessment preserved, with deferred assurance checkpoint explicit.
- Totals: 5 Done, 1 Blocked, 2 In review, 97 Not started. B009 explicitly not started.

### 20 October 2026 UTC — B009 local structure prepared

- User selected B009. Added meaningful project/documentation entry points and a layout guide; linked the original handover in place.
- Preserved original materials and all prior evidence; remote alignment remains unverified and deferred.
- Totals: 5 Done, 1 Blocked, 3 In review, 96 Not started. No runtime implementation or B010 work.

## 11. Current handoff

**Deliverable:** [Project README](README.md), [documentation index](docs/README.md), [layout guide](docs/project-layout.md), [B009 report](docs/evidence/B009-local-structure.md).  
**Status:** B009 In review for the approved local slice; B010–B105 Not started. B004 remains Blocked; B005/B007 remain In review.  
**Acceptance action:** Accept B009's local structure and source-reference deliverable; this does not claim remote compatibility or approve application architecture.  
**Boundary:** Stop before B010; setup/runtime/tooling decisions and any network-dependent actions require their own authorised scope. GitHub remains prohibited.
