"use client";
import { useEffect, useRef, useState } from "react";
import { DashboardData, isDashboard, kinds, states, validFilters } from "../lib/dashboard";

export default function Dashboard({ enabled = false }: { enabled?: boolean }) {
  const [filters, setFilters] = useState({ kind: "", state: "", owner_id: "" });
  const [data, setData] = useState<DashboardData | null>(null);
  const [message, setMessage] = useState("Sign in to view synthetic references.");
  const [busy, setBusy] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const sequence = useRef(0);
  const active = useRef<AbortController | null>(null);
  const result = useRef<HTMLParagraphElement>(null);
  function params(values = filters) {
    const p = new URLSearchParams();
    Object.entries(values).forEach(([key, value]) => { if (value) p.set(key, value); });
    return p;
  }
  async function load(p: URLSearchParams, focus = true) {
    const current = ++sequence.current;
    active.current?.abort(); active.current = new AbortController();
    setData(null); setBusy(true); setMessage("Loading references…");
    try {
      if (!validFilters(p)) throw new Error("filters");
      const response = await fetch(`/api/dashboard?${p}`, { cache: "no-store", credentials: "same-origin", redirect: "error", signal: active.current.signal });
      if (current !== sequence.current) return;
      if (response.status === 401) { setSignedIn(false); setMessage("Session expired or unavailable. Sign in to the synthetic fixture."); return; }
      if (response.status === 403) { setMessage("Access denied. Dashboard access is not permitted."); return; }
      if (response.status === 422) throw new Error("filters");
      if (!response.ok) throw new Error("service");
      const value: unknown = await response.json();
      if (current !== sequence.current) return;
      if (!isDashboard(value)) throw new Error("service");
      setSignedIn(true); setData(value);
      setMessage(value.status === "unavailable" ? "This reference type is not available. No count can be shown."
        : value.status === "empty" ? "No accessible references match these filters."
        : `${value.total} accessible synthetic ${value.total === 1 ? "reference matches" : "references match"} these filters.`);
    } catch (error) {
      if (current !== sequence.current) return;
      setMessage(error instanceof Error && error.message === "filters" ? "Check the filters. Owner must be a UUID."
        : "Could not load references. Counts are unavailable. Retry when the local service recovers.");
    } finally {
      if (current === sequence.current) { setBusy(false); if (focus) requestAnimationFrame(() => result.current?.focus()); }
    }
  }
  async function session(action: "login" | "logout") {
    ++sequence.current; active.current?.abort(); setData(null); setBusy(true);
    setMessage(action === "login" ? "Signing in…" : "Signing out…");
    try {
      const response = await fetch(`/api/session/${action}`, { method: "POST", cache: "no-store", redirect: "error" });
      if (!response.ok) throw new Error();
      setSignedIn(action === "login");
      if (action === "login") { await load(params()); return; }
      setMessage("Signed out. Synthetic references are hidden.");
    } catch { setMessage(action === "logout" ? "Sign-out not confirmed. Retry when the service recovers." : "Sign-in unavailable. Retry when the service recovers."); }
    finally { setBusy(false); requestAnimationFrame(() => result.current?.focus()); }
  }
  useEffect(() => {
    if (!enabled) return;
    const p = new URLSearchParams(window.location.search);
    setFilters({ kind: p.get("kind") ?? "", state: p.get("state") ?? "", owner_id: p.get("owner_id") ?? "" });
    void load(p, false);
    return () => { ++sequence.current; active.current?.abort(); };
    // Initial URL is the saved filter selection; submissions replace it.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);
  if (!enabled) return <section className="panel"><h2>Reference dashboard</h2><p>Not connected. Sign-in and record queries are available only in the isolated synthetic verification harness.</p></section>;
  return <div className="dashboard-page">
    <header className="page-heading"><div><p className="eyebrow">ISOLATED LOCAL VERIFICATION · SYNTHETIC DATA ONLY</p>
      <h1>Reference dashboard</h1><p>Permission-filtered reference metadata. These are test records, not business activity.</p></div>
      <div className="dashboard-session">{!signedIn && <button className="primary-link" disabled={busy} onClick={() => session("login")}>Sign in to synthetic fixture</button>}
        <button className="primary-link" disabled={busy} onClick={() => session("logout")}>Sign out</button></div></header>
    <form className="panel dashboard-filters" onSubmit={event => { event.preventDefault(); const p = params(); window.history.replaceState(null, "", `${window.location.pathname}${p.size ? `?${p}` : ""}`); void load(p); }}>
      <label>Reference type<select disabled={busy} value={filters.kind} onChange={e => { setData(null); setMessage("Filters changed. Apply filters to load matching references."); setFilters({ ...filters, kind: e.target.value }); }}>
        <option value="">All enabled types</option>{kinds.map(k => <option key={k} value={k}>{k.replaceAll("_", " ")}</option>)}</select></label>
      <label>State<select disabled={busy} value={filters.state} onChange={e => { setData(null); setMessage("Filters changed. Apply filters to load matching references."); setFilters({ ...filters, state: e.target.value }); }}>
        <option value="">All states</option>{states.map(s => <option key={s}>{s}</option>)}</select></label>
      <label>Owner UUID <span>(optional)</span><input disabled={busy} value={filters.owner_id} onChange={e => { setData(null); setMessage("Filters changed. Apply filters to load matching references."); setFilters({ ...filters, owner_id: e.target.value }); }} spellCheck={false} autoComplete="off" /></label>
      <button className="primary-link" disabled={busy}>Apply filters</button>
    </form>
    <p ref={result} tabIndex={-1} role="status" aria-live="polite">{message}</p>
    <div className="dashboard-cards" aria-busy={busy}>
      <section className="panel"><h2>Visible references</h2><strong className="dashboard-count">{data?.total ?? "—"}</strong><p>{data?.total === null || !data ? "Count unavailable" : "Synthetic records matching the applied filters"}</p></section>
      <section className="panel"><h2>Business metrics</h2><strong>Not available</strong><p>Revenue, research activity and review metrics are not connected.</p></section>
    </div>
    <section className="panel dashboard-list" aria-busy={busy}><h2>Accessible references</h2>
      {data?.status === "ok" ? <ul>{data.records.map(r => <li key={r.id}><strong>{r.kind.replaceAll("_", " ")}</strong><span className="quiet-badge">{r.state}</span><span>Reference <code>{r.id}</code></span><span>Owner <code>{r.owner_id}</code></span></li>)}</ul>
        : <p>{busy ? "Loading references…" : data?.status === "empty" ? "No matching references. Adjust the filters and try again." : "No reference list available."}</p>}
      <button className="primary-link" disabled={busy} onClick={() => load(params())}>Retry / refresh</button>
    </section>
    <section className="panel"><h2>Deferred capabilities</h2><p>Scanning and voice are not available. No service can be started from this dashboard.</p></section>
  </div>;
}
