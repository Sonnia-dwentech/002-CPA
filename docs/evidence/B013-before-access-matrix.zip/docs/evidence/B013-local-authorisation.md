# B013 — Local Identity and Record Authorisation Preparation

**Date:** 20 October 2026 UTC  
**Authority:** User “Start B013”, under G0-L; subsequent B012 disposable database execution authorised separately  
**Status:** Blocked for implementation; independent local design preparation delivered  
**Executor:** Codex; Justice remains nominated technical authority

## Scope and prerequisites

[B013](../../build-order.md) requires identity/user references and the approved role/record authorisation boundary. Its unchanged completion check is: “Permission tests deny unauthorised records; tenancy assumptions are explicit before client records exist.”

The [work-item card](../planning/phase-1-work-items.md#b013) depends on B012, O-04 ownership/sharing/tenancy decisions and B006 deferred technical review. B012's local preparation report is user-approved but PostgreSQL implementation and verification remain blocked by the explicit setup deferral. [ADR-002](../adr/002-identity-roles-tenancy.md) is proposed, and O-04 remains open. The existing backend provides liveness/OpenAPI/error handling; it has no user store or protected record routes.

The user's selection permits this local dependency review and decision/test worksheet. It does not resolve database readiness or approve unspecified business grants. No database, provider, account, credential, schema or application permission was created. B014 is not started.

## Work independent of B012

- Identify who must decide each business and technical access rule.
- Specify the information needed at the server authorisation boundary without choosing database columns or an identity provider.
- Prepare positive and negative test cases against synthetic actors, with positive grants left pending until approved.
- Trace future API/search/export/file/job checks to F01 and document what local mock tests would and would not prove.

Persisted user references, ownership relationships, integrity constraints, database-backed filtering and their real integration tests require B012's approved schema/migration/connectivity foundation. A future isolated policy test can precede that foundation only after its own grants and policy contract are approved; it cannot establish persisted isolation.

## Approval worksheet

Justice owns technical decisions with the product owner for business grants, as recorded in [O-04](../../decisions.md). The user previously nominated Justice as interim product/scope approver; no decision below is inferred from that nomination.

| Decision | Concrete outcome required | Current state |
| --- | --- | --- |
| Initial actor scope | Internal humans only, or explicit client access in the initial scope; treatment of future analysts | User selected inclusion of client sign-in in the local proposal; future analyst scope and actual release enablement remain undecided |
| Identity references | Source of verified identity; stable subject mapping, uniqueness and disabled/deleted-account handling | Unselected; do not trust caller-supplied user IDs |
| Role/action/resource matrix | For each enabled role: explicitly permitted actions, resource types and scope; who assigns/revokes grants | Unapproved; titles confer no automatic access |
| Ownership and sharing | Who owns new records; private versus team-visible defaults; explicit sharing, transfer and revocation rules | Unapproved; ownership alone is not an assumed allow rule |
| Tenancy | Internal workspace boundary; how future client data is separated; membership source and cross-scope exceptions, if any | Unapproved; no client records permitted |
| Administration | Whether an application admin exists; exact grants and any elevated-access controls | Unapproved; Justice/CEO/developer roles do not imply unrestricted record access |
| Server policy contract | Trusted actor context, scope resolution, denial response, query filtering and policy enforcement on derived outputs | Proposal below, subject to technical review |
| Security/policy review | B006 technical review for the selected access boundary and synthetic fixtures | Deferred; no sign-off inferred |

Session/provider integration is B014 work. B013 needs an agreed trusted-identity contract to avoid inventing that integration. No provider account, session lifetime or recovery mechanism is selected here.

### Grant worksheet to complete before allow-path code

Complete one row per approved role/action/resource combination, rather than approving broad role names. Required fields:

`Role | Resource type | Action | Ownership/membership condition | Sharing condition | Explicit allow or deny | Grant authority | Revocation behaviour | Approver/date`

Potential actors are the Founder/CEO, human CPA, Justice, human assistant developer, future analyst and Discovery client. Client sign-in is included in this proposal by user direction; specific role enablement and all grants remain undecided. AI cannot exercise human approval/investment/contract/release authority. No allow rows are populated because the source documents do not approve them.

## Client sign-in proposal scope — user decision, 20 October 2026 UTC

User: “Include client sign-in in the proposal”. The design must consider client identities alongside internal human identities now. This is proposal scope, not approval to implement a client portal or move Discovery delivery into Phase 1. B014 authentication integration remains unstarted.

The client design must resolve:

- How a client account is enrolled and verified, and who may establish or revoke its membership in a client organisation. Invitation versus self-registration remains unselected.
- Whether one client organisation may have multiple users, whether a user may belong to several clients, and how active scope is selected and checked. Do not derive membership from a submitted client ID or email domain alone.
- Which intake, approved-response, file and other actions are explicitly granted; how ownership/sharing works within a client organisation; which internal staff may access those records. No grants are inferred from successful sign-in.
- Account suspension, membership removal and session revocation behaviour, with the authentication contract completed under separately selected B014 work.

Extend the planned synthetic checks to cover signed-in clients without membership, membership in another client, forged scope changes, client attempts to use internal-only actions and revoked membership. Include an allowed client action only after its grant is approved. These cases are planned, not executed. Real-client data remains prohibited.

[Pre-change snapshot](B013-before-client-scope.zip) preserves the report, tracker and decision register before this clarification. B012/B013 remain Blocked and no task status changes.

## Proposed server contract for technical review

1. Receive a verified actor context through the later approved authentication boundary, never from an arbitrary request user/role/client field.
2. Resolve the resource and its ownership/scope from trusted application state. Unknown identity, resource scope, action or required policy data must not produce an allow decision.
3. Evaluate explicit role/action/resource grants together with the approved ownership/sharing/tenancy rules. Missing approval is not a permissive default.
4. Apply the same scope to direct reads/writes and collections, counts, search, file downloads, exports and job outputs. Recheck current permissions when a delayed output is retrieved.
5. Return only the approved public denial response; do not expose record existence/content or internal policy details. Decide 403-versus-concealed-404 semantics before endpoint tests.

These properties reflect F01 and ADR-002; they are a proposed implementation contract, not implemented controls. B011 public liveness remains separate from protected application records.

## Planned verification matrix — no tests run

| Case | Expected outcome / decision dependency |
| --- | --- |
| Missing/unverified actor | Deny protected access; authentication integration verified later with B014 |
| Authenticated actor with no applicable grant | Deny; no protected content or derived private information |
| Explicitly permitted actor and matching record scope | Allow only the approved action; positive grant needed before encoding expectation |
| Owner without an approved action grant | Do not infer allow from ownership; encode final approved ownership rule |
| Different synthetic owner or client changes a direct record ID | Deny unauthorised record access; tenancy model needed for fixture construction |
| Request spoofs role, user or client fields | No privilege change; use trusted context/state |
| List/search/count/export/file/job uses a restricted record | No restricted content or derived private information through alternate paths |
| Grant/membership revoked after job starts | No retrieval based only on stale privileges; final revocation contract required |
| Unknown action, missing scope or policy failure | Fail closed; no fallback global access |
| API/database integration | Verify real persisted scoping after B012; mock success alone cannot pass this check |

Synthetic fixture plan: create distinct fictional actors and two isolated client scopes only after the scope/schema is approved. Record a manifest with synthetic origin, purpose, expected results, schema/version, owner, location and cleanup method under B006. No fixtures or persistent test stores have been created.

## Completion and handoff

To complete B013, resolve the task-level approvals above, unblock and verify the required B012 persistence foundation, implement the approved boundary, and run positive and negative permission checks. Record explicit tenancy assumptions before any client records exist. Retain independent review and original governance checks before shared integration/deployment.

This preparation does not meet B013's implementation acceptance criteria. Local policy design can continue while database setup is deferred; database changes and invented access grants cannot.

[Pre-edit snapshot](B013-before.zip) and [input hashes](B013-input-hashes.json) preserve the starting state. Only progress.md and the documentation index are edited; this report and preservation artifacts are new. Existing backend, original sources, prior evidence and build-order definitions remain unchanged. No GitHub, downloads, installs, external service calls or database actions occurred.

## B012 dependency update — 20 October 2026 UTC

The user subsequently lifted the B012 setup deferral for disposable local PostgreSQL work. Nine actual database checks and nine API checks passed; see [current B012 evidence](B012-local-database.md). B012 is now In review, with no persistent database retained. Earlier references to the setup deferral above describe the preparation snapshot. B013 remains Blocked pending its identity/grant/ownership/tenancy decisions, B006 technical review and B012 acceptance. Client sign-in remains in proposal scope only. No B013 implementation or permission tests occurred.

## B012 acceptance update — 20 October 2026 UTC

User accepted B012's executed local deliverable. B012 is Done and its local acceptance prerequisite is satisfied. B013 remains Blocked by unresolved identity/grant/ownership/tenancy decisions and B006 technical review. The database check destination was disposable and removed; future persistence work must use an authorised isolated destination. No B013 code or B014 work performed during this update.
